#!/usr/bin/env python3
"""
n8n_builder — construye workflows de n8n importables con layout automático.

Por qué existe: escribir a mano el JSON de n8n es propenso a errores (ids duplicados,
conexiones a nodos que no existen, posiciones que se encimen, expresiones sin "=").
Este módulo genera la estructura correcta y deja a Claude concentrarse en la lógica.

Uso mínimo:

    import sys; sys.path.insert(0, "<ruta>/scripts")
    from n8n_builder import Workflow

    wf = Workflow("Mi flujo", timezone="America/Mexico_City")
    wf.webhook("Webhook", path="nuevo-lead", respond="responseNode")
    wf.set("Normalizar", {"email": "{{ $json.body.email.toLowerCase() }}"})
    wf.respond("Responder OK", body={"ok": True})
    wf.chain("Webhook", "Normalizar", "Responder OK")
    wf.save("mi-flujo.json")

Salida: JSON con SOLO name/nodes/connections/settings. Es el subconjunto que aceptan
tanto "Import from file" de la UI como POST /api/v1/workflows de la API pública.
"""
import json
import re
import uuid
from collections import defaultdict

AI_CONN_TYPES = (
    "ai_languageModel", "ai_memory", "ai_tool", "ai_outputParser", "ai_embedding",
    "ai_vectorStore", "ai_document", "ai_textSplitter", "ai_retriever", "ai_reranker",
)

# alias -> (type, typeVersion). Versiones conservadoras: n8n abre sin problema nodos con
# typeVersion anterior a la última (los migra al abrir). Una versión demasiado NUEVA para la
# instancia, en cambio, sí rompe la importación; por eso se evita ir en el borde.
TYPES = {
    "manualTrigger": ("n8n-nodes-base.manualTrigger", 1),
    "scheduleTrigger": ("n8n-nodes-base.scheduleTrigger", 1.2),
    "webhook": ("n8n-nodes-base.webhook", 2),
    "errorTrigger": ("n8n-nodes-base.errorTrigger", 1),
    "executeWorkflowTrigger": ("n8n-nodes-base.executeWorkflowTrigger", 1.1),
    "chatTrigger": ("@n8n/n8n-nodes-langchain.chatTrigger", 1.1),
    "respondToWebhook": ("n8n-nodes-base.respondToWebhook", 1.1),
    "httpRequest": ("n8n-nodes-base.httpRequest", 4.2),
    "set": ("n8n-nodes-base.set", 3.4),
    "if": ("n8n-nodes-base.if", 2.2),
    "filter": ("n8n-nodes-base.filter", 2.2),
    "switch": ("n8n-nodes-base.switch", 3.2),
    "code": ("n8n-nodes-base.code", 2),
    "merge": ("n8n-nodes-base.merge", 3.1),
    "splitInBatches": ("n8n-nodes-base.splitInBatches", 3),
    "splitOut": ("n8n-nodes-base.splitOut", 1),
    "aggregate": ("n8n-nodes-base.aggregate", 1),
    "wait": ("n8n-nodes-base.wait", 1.1),
    "noOp": ("n8n-nodes-base.noOp", 1),
    "executeWorkflow": ("n8n-nodes-base.executeWorkflow", 1.2),
    "stickyNote": ("n8n-nodes-base.stickyNote", 1),
    "agent": ("@n8n/n8n-nodes-langchain.agent", 2.2),
    "lmChatOpenAi": ("@n8n/n8n-nodes-langchain.lmChatOpenAi", 1.2),
    "lmChatAnthropic": ("@n8n/n8n-nodes-langchain.lmChatAnthropic", 1.3),
    "memoryBufferWindow": ("@n8n/n8n-nodes-langchain.memoryBufferWindow", 1.3),
    "toolHttpRequest": ("@n8n/n8n-nodes-langchain.toolHttpRequest", 1.1),
    "outputParserStructured": ("@n8n/n8n-nodes-langchain.outputParserStructured", 1.3),
}

TRIGGER_ALIASES = {"manualTrigger", "scheduleTrigger", "webhook", "errorTrigger",
                   "executeWorkflowTrigger", "chatTrigger"}
UNARY_OPS = {"empty", "notEmpty", "true", "false", "exists", "notExists"}

NODE_W, NODE_H = 240, 180          # separación horizontal / vertical del layout
AI_ROW_OFFSET = 230                # distancia vertical de sub-nodos de IA a su padre


def _uid():
    return str(uuid.uuid4())


def expr(s):
    """Marca un string como expresión n8n (prefijo '=') si contiene {{ }} y aún no lo tiene."""
    if isinstance(s, str) and "{{" in s and not s.startswith("="):
        return "=" + s
    return s


def _walk_expr(obj):
    """Aplica expr() recursivamente a strings dentro de dicts/listas."""
    if isinstance(obj, str):
        return expr(obj)
    if isinstance(obj, list):
        return [_walk_expr(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _walk_expr(v) for k, v in obj.items()}
    return obj


def rl(value, mode="id", **extra):
    """Resource locator ({__rl: true, ...}) que usan muchos nodos para documentos, canales, etc."""
    d = {"__rl": True, "value": value, "mode": mode}
    d.update(extra)
    return d


def conditions(items, combinator="and", loose=False):
    """
    Construye el bloque 'conditions' que usan IF / Filter / Switch (v2+).
    items: lista de (left, tipo, operacion, right). tipo: string|number|boolean|dateTime|array|object.
    Ej.: ("{{ $json.status }}", "string", "equals", "active")
         ("{{ $json.email }}", "string", "notEmpty")      # operadores unarios sin right
    """
    conds = []
    for it in items:
        left, typ, op = it[0], it[1], it[2]
        right = it[3] if len(it) > 3 else ""
        operator = {"type": typ, "operation": op}
        if op in UNARY_OPS:
            operator["singleValue"] = True
        conds.append({
            "id": _uid(),
            "leftValue": expr(left),
            "rightValue": expr(right) if isinstance(right, str) else right,
            "operator": operator,
        })
    return {
        "options": {"caseSensitive": True, "leftValue": "",
                    "typeValidation": "loose" if loose else "strict", "version": 2},
        "conditions": conds,
        "combinator": combinator,
    }


class Workflow:
    def __init__(self, name, timezone="America/Mexico_City", error_workflow=None,
                 save_success="all", save_error="all", execution_timeout=None,
                 save_manual=True):
        self.name = name
        self.nodes = []
        self.connections = {}
        self._by_name = {}
        self._fixed_pos = set()
        self._ai_parent = {}          # sub-nodo IA -> nodo padre
        self.settings = {"executionOrder": "v1", "timezone": timezone,
                         "saveDataSuccessExecution": save_success,
                         "saveDataErrorExecution": save_error,
                         "saveManualExecutions": save_manual}
        if error_workflow:
            self.settings["errorWorkflow"] = error_workflow
        if execution_timeout:
            self.settings["executionTimeout"] = execution_timeout

    # ------------------------------------------------------------------ nodos
    def add(self, name, type_key, params=None, *, version=None, credentials=None, pos=None,
            notes=None, on_error=None, retry=None, always_output=None, execute_once=None,
            webhook_id=None, disabled=False):
        """
        Añade un nodo genérico. type_key = alias de TYPES o tipo completo
        ('n8n-nodes-base.gmail'); con tipo completo, pasa version=.
        on_error: 'continueRegularOutput' | 'continueErrorOutput' | 'stopWorkflow'
        retry: (max_tries, ms_entre_intentos)  -> retryOnFail
        """
        if name in self._by_name:
            raise ValueError(f"Nombre de nodo duplicado: {name!r} (n8n exige nombres únicos)")
        if type_key in TYPES:
            ntype, nver = TYPES[type_key]
        else:
            if version is None:
                raise ValueError(f"Para el tipo {type_key!r} indica version=")
            ntype, nver = type_key, version
        if version is not None:
            nver = version
        node = {
            "parameters": _walk_expr(params or {}),
            "id": _uid(),
            "name": name,
            "type": ntype,
            "typeVersion": nver,
            "position": list(pos) if pos else [0, 0],
        }
        if credentials:
            node["credentials"] = credentials
        if webhook_id or ntype in ("n8n-nodes-base.webhook", "@n8n/n8n-nodes-langchain.chatTrigger"):
            node["webhookId"] = webhook_id or _uid()
        if on_error:
            node["onError"] = on_error
        if retry:
            node["retryOnFail"] = True
            node["maxTries"] = retry[0]
            node["waitBetweenTries"] = retry[1]
        if always_output is not None:
            node["alwaysOutputData"] = always_output
        if execute_once is not None:
            node["executeOnce"] = execute_once
        if notes:
            node["notes"] = notes
            node["notesInFlow"] = True
        if disabled:
            node["disabled"] = True
        if pos:
            self._fixed_pos.add(name)
        self.nodes.append(node)
        self._by_name[name] = node
        return name

    def credential(self, cred_type, display_name):
        """Referencia de credencial. Sin id real: al importar, n8n pide elegir/crear la credencial."""
        return {cred_type: {"id": "", "name": display_name}}

    # --------------------------------------------------------- nodos de uso común
    def manual(self, name="Manual Trigger"):
        return self.add(name, "manualTrigger")

    def webhook(self, name, path, method="POST", respond="onReceived", auth=None, raw_body=False):
        """respond: 'onReceived' (responde 200 al instante) | 'lastNode' | 'responseNode'
        auth: None | 'headerAuth' | 'basicAuth' (la credencial se elige tras importar)."""
        p = {"httpMethod": method, "path": path, "options": {}}
        if respond != "onReceived":
            p["responseMode"] = respond
        if raw_body:
            p["options"]["rawBody"] = True
        creds = None
        if auth:
            p["authentication"] = auth
            ctype = {"headerAuth": "httpHeaderAuth", "basicAuth": "httpBasicAuth"}[auth]
            creds = self.credential(ctype, f"{name} auth")
        return self.add(name, "webhook", p, credentials=creds)

    def schedule(self, name="Schedule Trigger", cron=None, every_minutes=None, every_hours=None,
                 every_days_at_hour=None):
        if cron:
            rule = {"field": "cron", "expression": cron}
        elif every_minutes:
            rule = {"field": "minutes", "minutesInterval": every_minutes}
        elif every_hours:
            rule = {"field": "hours", "hoursInterval": every_hours}
        elif every_days_at_hour is not None:
            rule = {"field": "days", "daysInterval": 1, "triggerAtHour": every_days_at_hour}
        else:
            raise ValueError("schedule(): indica cron, every_minutes, every_hours o every_days_at_hour")
        return self.add(name, "scheduleTrigger", {"rule": {"interval": [rule]}})

    def error_trigger(self, name="Error Trigger"):
        return self.add(name, "errorTrigger")

    def sub_workflow_trigger(self, name="When Executed by Another Workflow"):
        return self.add(name, "executeWorkflowTrigger", {"inputSource": "passthrough"})

    def http(self, name, method, url, *, headers=None, query=None, json_body=None,
             auth=None, timeout_ms=30000, retry=(3, 2000), on_error=None, pagination=None,
             batch=None, response_format=None):
        """
        auth: None | ('predefinedCredentialType', 'slackApi') | ('genericCredentialType', 'httpHeaderAuth')
        pagination: dict ya con la forma de n8n si se necesita (ver references/node-catalog.md).
        batch: (batchSize, intervalMs) para no superar rate limits.
        """
        p = {"method": method, "url": url, "options": {"timeout": timeout_ms}}
        creds = None
        if auth:
            kind, ctype = auth
            p["authentication"] = kind
            p["nodeCredentialType" if kind == "predefinedCredentialType" else "genericAuthType"] = ctype
            creds = self.credential(ctype, f"{ctype}")
        if headers:
            p["sendHeaders"] = True
            p["headerParameters"] = {"parameters": [{"name": k, "value": v} for k, v in headers.items()]}
        if query:
            p["sendQuery"] = True
            p["queryParameters"] = {"parameters": [{"name": k, "value": v} for k, v in query.items()]}
        if json_body is not None:
            p["sendBody"] = True
            p["specifyBody"] = "json"
            p["contentType"] = "json"
            p["jsonBody"] = json_body if isinstance(json_body, str) else json.dumps(json_body, ensure_ascii=False)
        if pagination:
            p["options"]["pagination"] = pagination
        if batch:
            p["options"]["batching"] = {"batch": {"batchSize": batch[0], "batchInterval": batch[1]}}
        if response_format:
            p["options"]["response"] = {"response": {"responseFormat": response_format}}
        return self.add(name, "httpRequest", p, credentials=creds, retry=retry, on_error=on_error)

    def set(self, name, fields, include_other=False):
        """fields: {campo: valor}. Strings con {{ }} se convierten en expresión automáticamente."""
        assigns = []
        for k, v in fields.items():
            if isinstance(v, bool):
                typ, val = "boolean", v
            elif isinstance(v, (int, float)):
                typ, val = "number", v
            elif isinstance(v, (dict, list)):
                typ, val = ("object" if isinstance(v, dict) else "array"), json.dumps(v, ensure_ascii=False)
            else:
                typ, val = "string", expr(v)
            assigns.append({"id": _uid(), "name": k, "value": val, "type": typ})
        p = {"assignments": {"assignments": assigns}, "options": {}}
        if include_other:
            p["includeOtherFields"] = True
        return self.add(name, "set", p)

    def if_(self, name, items, combinator="and", loose=False):
        """Salida 0 = true, salida 1 = false. Ver conditions() para el formato de items."""
        return self.add(name, "if", {"conditions": conditions(items, combinator, loose), "options": {}})

    def filter(self, name, items, combinator="and"):
        return self.add(name, "filter", {"conditions": conditions(items, combinator), "options": {}})

    def switch(self, name, rules, fallback=True):
        """rules: lista de (nombre_salida, items_de_conditions). Las salidas se numeran en orden;
        con fallback=True se agrega una última salida 'extra' para lo que no coincide."""
        values = [{"conditions": conditions(items), "renameOutput": True, "outputKey": out_name}
                  for out_name, items in rules]
        opts = {"fallbackOutput": "extra"} if fallback else {}
        return self.add(name, "switch", {"rules": {"values": values}, "options": opts})

    def code(self, name, js, per_item=False):
        """JavaScript. En modo 'todos los items' DEBE devolver [{json: {...}}, ...].
        En 2.x el Code node no accede a variables de entorno ($env / process.env)."""
        p = {"jsCode": js}
        if per_item:
            p["mode"] = "runOnceForEachItem"
        return self.add(name, "code", p)

    def split_batches(self, name, size=10):
        """OJO: salida 0 = 'done' (terminó), salida 1 = 'loop' (siguiente lote)."""
        return self.add(name, "splitInBatches", {"batchSize": size, "options": {}})

    def merge(self, name, mode="append", match_field=None, join_mode="keepMatches"):
        p = {}
        if mode == "append":
            pass
        elif mode == "combine_by_field":
            p = {"mode": "combine", "combineBy": "combineByFields",
                 "fieldsToMatchString": match_field, "joinMode": join_mode, "options": {}}
        elif mode == "combine_by_position":
            p = {"mode": "combine", "combineBy": "combineByPosition", "options": {}}
        else:
            raise ValueError("merge(): mode = append | combine_by_field | combine_by_position")
        return self.add(name, "merge", p)

    def respond(self, name, body=None, code=200, headers=None):
        p = {"respondWith": "json" if body is not None else "noData",
             "options": {"responseCode": code}}
        if body is not None:
            p["responseBody"] = body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)
        if headers:
            p["options"]["responseHeaders"] = {"entries": [{"name": k, "value": v} for k, v in headers.items()]}
        return self.add(name, "respondToWebhook", p)

    def wait(self, name, amount=1, unit="minutes"):
        return self.add(name, "wait", {"resume": "timeInterval", "amount": amount, "unit": unit})

    def execute_workflow(self, name, workflow_id="", wait=True):
        return self.add(name, "executeWorkflow",
                        {"source": "database", "workflowId": rl(workflow_id, "id"),
                         "options": {"waitForSubWorkflow": wait}})

    def noop(self, name):
        return self.add(name, "noOp")

    def sticky(self, content, name=None, width=480, height=240, color=4, pos=None):
        """Nota adhesiva (documentación dentro del lienzo). Se ubica arriba-izquierda si no das pos."""
        name = name or f"Sticky Note {sum(1 for n in self.nodes if n['type'].endswith('stickyNote')) + 1}"
        self.add(name, "stickyNote", {"content": content, "height": height, "width": width,
                                       "color": color}, pos=pos)
        return name

    # ------------------------------------------------------------- IA (LangChain)
    def agent(self, name, system_message, prompt="={{ $json.chatInput }}", output_parser=False):
        p = {"promptType": "define", "text": prompt, "options": {"systemMessage": system_message}}
        if output_parser:
            p["hasOutputParser"] = True
        return self.add(name, "agent", p)

    def chat_model(self, name, parent, provider="anthropic", model=None):
        if provider == "anthropic":
            self.add(name, "lmChatAnthropic",
                     {"model": rl(model or "claude-sonnet-5-5", "id"), "options": {}},
                     credentials=self.credential("anthropicApi", "Anthropic account"))
        elif provider == "openai":
            self.add(name, "lmChatOpenAi",
                     {"model": rl(model or "gpt-4o-mini", "id"), "options": {}},
                     credentials=self.credential("openAiApi", "OpenAI account"))
        else:
            raise ValueError("provider = anthropic | openai (otros: usa add() con el tipo completo)")
        self.connect_ai(name, parent, "ai_languageModel")
        return name

    def memory(self, name, parent, session_key="={{ $json.sessionId }}", window=10):
        self.add(name, "memoryBufferWindow", {"sessionIdType": "customKey", "sessionKey": session_key,
                                              "contextWindowLength": window})
        self.connect_ai(name, parent, "ai_memory")
        return name

    # ------------------------------------------------------------- conexiones
    def connect(self, src, dst, output=0, input=0):
        """src[output] -> dst[input]. Para IF: output 0 = true, 1 = false."""
        for n in (src, dst):
            if n not in self._by_name:
                raise ValueError(f"connect(): el nodo {n!r} no existe (¿lo creaste antes?)")
        slots = self.connections.setdefault(src, {}).setdefault("main", [])
        while len(slots) <= output:
            slots.append([])
        slots[output].append({"node": dst, "type": "main", "index": input})

    def chain(self, *names):
        for a, b in zip(names, names[1:]):
            self.connect(a, b)

    def connect_ai(self, sub, parent, kind):
        """Sub-nodo de IA (modelo, memoria, tool, parser) -> nodo padre (agent / chain)."""
        assert kind in AI_CONN_TYPES, f"kind debe ser uno de {AI_CONN_TYPES}"
        for n in (sub, parent):
            if n not in self._by_name:
                raise ValueError(f"connect_ai(): el nodo {n!r} no existe")
        self.connections.setdefault(sub, {})[kind] = [[{"node": parent, "type": kind, "index": 0}]]
        self._ai_parent[sub] = parent

    # ---------------------------------------------------------------- layout
    def _layout(self):
        names = [n["name"] for n in self.nodes
                 if n["type"] != "n8n-nodes-base.stickyNote" and n["name"] not in self._ai_parent]
        edges = defaultdict(list)           # solo conexiones main
        indeg = defaultdict(int)
        for src, kinds in self.connections.items():
            for outs in kinds.get("main", []):
                for c in outs:
                    if src in names and c["node"] in names:
                        edges[src].append(c["node"])
                        indeg[c["node"]] += 1
        roots = [n for n in names if indeg[n] == 0]

        # 1) aristas de retorno (ciclos / loops) por DFS iterativo
        color, back = {}, set()
        for r in roots or names[:1]:
            stack = [(r, iter(edges[r]))]
            color[r] = 1
            while stack:
                node, it = stack[-1]
                for nxt in it:
                    if color.get(nxt) == 1:
                        back.add((node, nxt))
                    elif nxt not in color:
                        color[nxt] = 1
                        stack.append((nxt, iter(edges[nxt])))
                        break
                else:
                    color[node] = 2
                    stack.pop()

        dag = {n: [m for m in edges[n] if (n, m) not in back] for n in names}
        din = defaultdict(int)
        for n in names:
            for m in dag[n]:
                din[m] += 1

        # 2) nivel = camino más largo desde una raíz (Kahn)
        level = {n: 0 for n in names}
        queue = [n for n in names if din[n] == 0]
        while queue:
            n = queue.pop(0)
            for m in dag[n]:
                level[m] = max(level[m], level[n] + 1)
                din[m] -= 1
                if din[m] == 0:
                    queue.append(m)

        # 3) carriles (filas): el primer hijo hereda la fila del padre; los demás abren una nueva
        lane, counter = {}, [0]

        def assign(n, ln):
            if n in lane:
                return
            lane[n] = ln
            first = True
            for m in dag[n]:
                if m in lane:
                    continue
                if first:
                    assign(m, ln)
                    first = False
                else:
                    counter[0] += 1
                    assign(m, counter[0])

        for r in roots or names[:1]:
            if r not in lane:
                if lane:
                    counter[0] += 1
                assign(r, counter[0])
        for n in names:                       # nodos sueltos
            if n not in lane:
                counter[0] += 1
                lane[n] = counter[0]

        row_h = NODE_H + (AI_ROW_OFFSET if self._ai_parent else 0)
        for n in names:
            if n in self._fixed_pos:
                continue
            self._by_name[n]["position"] = [level[n] * NODE_W, lane[n] * row_h]

        # sub-nodos de IA debajo de su padre
        kids = defaultdict(list)
        for sub, parent in self._ai_parent.items():
            kids[parent].append(sub)
        for parent, subs in kids.items():
            px, py = self._by_name[parent]["position"]
            for i, s in enumerate(subs):
                if s in self._fixed_pos:
                    continue
                self._by_name[s]["position"] = [px + int((i - (len(subs) - 1) / 2) * 200), py + AI_ROW_OFFSET]

        # sticky notes sin posición: arriba a la izquierda del flujo
        placed = [self._by_name[n]["position"] for n in names]
        min_x = min((p[0] for p in placed), default=0)
        min_y = min((p[1] for p in placed), default=0)
        offset = 0
        for node in self.nodes:
            if node["type"] == "n8n-nodes-base.stickyNote" and node["name"] not in self._fixed_pos:
                h = node["parameters"].get("height", 240)
                node["position"] = [min_x - 40, min_y - h - 80 - offset]
                offset += h + 40

    # ---------------------------------------------------------------- salida
    def to_dict(self):
        self._layout()
        return {"name": self.name, "nodes": self.nodes,
                "connections": self.connections, "settings": self.settings}

    def save(self, path):
        data = self.to_dict()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return path


if __name__ == "__main__":
    print(__doc__)
