#!/usr/bin/env python3
"""Validate an n8n workflow JSON file before delivering it.

Usage: python validate_workflow.py workflow.json [--strict]
Exit code 1 if errors (or warnings with --strict) are found.
Accepts a workflow object, or a list/object wrapping one ({"workflow": {...}} / [ {...} ]).
"""
import json
import re
import sys
from collections import Counter

TRIGGER_HINTS = ("trigger", "webhook", "cron", "emailreadimap", "formtrigger")
AI_CONN_TYPES = {"ai_languageModel", "ai_memory", "ai_tool", "ai_outputParser", "ai_embedding",
                 "ai_vectorStore", "ai_document", "ai_textSplitter", "ai_retriever", "ai_reranker"}
SECRET_KEY = re.compile(r"(api[_-]?key|token|secret|password|authorization|bearer)", re.I)
SECRET_VALUE = re.compile(r"(sk-[A-Za-z0-9]{16,}|xox[abp]-[A-Za-z0-9-]{10,}|ghp_[A-Za-z0-9]{20,}|"
                          r"AIza[0-9A-Za-z_-]{20,}|Bearer\s+[A-Za-z0-9._-]{16,})")
NETWORK_TYPES = ("httpRequest", "slack", "gmail", "googleSheets", "notion", "airtable", "telegram",
                 "postgres", "mySql", "stripe", "hubspot", "supabase", "twilio", "awsS3")


def load(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list) and data:
        data = data[0]
    if isinstance(data, dict) and "nodes" not in data and isinstance(data.get("workflow"), dict):
        data = data["workflow"]
    return data


def walk_strings(obj, path=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk_strings(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk_strings(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        yield path, obj


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    strict = "--strict" in sys.argv
    if not args:
        print(__doc__)
        sys.exit(2)
    try:
        wf = load(args[0])
    except Exception as e:  # noqa: BLE001
        print(f"ERROR: cannot parse JSON: {e}")
        sys.exit(1)

    errors, warnings = [], []
    nodes = wf.get("nodes")
    conns = wf.get("connections", {})
    if not isinstance(nodes, list) or not nodes:
        print("ERROR: 'nodes' missing or empty")
        sys.exit(1)
    if not isinstance(conns, dict):
        errors.append("'connections' must be an object")
        conns = {}
    if not wf.get("name"):
        warnings.append("workflow has no 'name'")
    if wf.get("active") is True:
        warnings.append("'active' is true: deliver inactive so the user can test first")

    names = [n.get("name") for n in nodes]
    ids = [n.get("id") for n in nodes]
    for name, c in Counter(names).items():
        if c > 1:
            errors.append(f"duplicate node name: '{name}' (connections are keyed by name)")
    for i, c in Counter(ids).items():
        if i and c > 1:
            errors.append(f"duplicate node id: {i}")
    nameset = set(names)

    by_name = {n.get("name"): n for n in nodes}
    for n in nodes:
        nm = n.get("name", "<no name>")
        for key in ("name", "type", "position", "parameters"):
            if key not in n and not (key == "parameters" and n.get("type", "").endswith("stickyNote")):
                errors.append(f"node '{nm}': missing '{key}'")
        if "typeVersion" not in n:
            errors.append(f"node '{nm}': missing 'typeVersion'")
        if not n.get("id"):
            warnings.append(f"node '{nm}': missing 'id'")
        pos = n.get("position")
        if pos is not None and not (isinstance(pos, list) and len(pos) == 2 and all(isinstance(x, (int, float)) for x in pos)):
            errors.append(f"node '{nm}': position must be [x, y] numbers")
        t = n.get("type", "")
        if not (t.startswith("n8n-nodes-base.") or t.startswith("@n8n/n8n-nodes-langchain.") or "." in t):
            errors.append(f"node '{nm}': suspicious type '{t}'")
        if re.search(r"(HTTP Request|Set|Code|IF|Switch|Merge|Webhook|Edit Fields|Slack|Gmail)\d+$", nm or ""):
            warnings.append(f"node '{nm}': default-looking name; use a descriptive one")

        params = n.get("parameters", {}) or {}
        # expression checks
        for p, s in walk_strings(params):
            if "{{" in s and not s.startswith("=") and t != "n8n-nodes-base.stickyNote" and not p.endswith(".jsCode") \
                    and not p.endswith(".content") and not p.endswith(".notes"):
                warnings.append(f"node '{nm}' {p}: contains '{{{{ }}}}' but doesn't start with '=' (won't evaluate)")
            if SECRET_VALUE.search(s):
                errors.append(f"node '{nm}' {p}: looks like a hardcoded secret; use a credential")
        for p, s in walk_strings(params):
            last = p.rsplit(".", 1)[-1].lower()
            if SECRET_KEY.search(last) and s and not s.startswith("=") and len(s) > 8 and "REPLACE" not in s.upper():
                errors.append(f"node '{nm}' {p}: secret-like parameter with literal value; use a credential")

        # Code node checks
        if t == "n8n-nodes-base.code":
            js = params.get("jsCode") or ""
            py = params.get("pythonCode") or ""
            code = js or py
            if not code.strip():
                warnings.append(f"Code node '{nm}' is empty")
            elif "return" not in code:
                errors.append(f"Code node '{nm}': no return statement")
            elif js and "json" not in js.split("return")[-1] and "$input" not in js.split("return")[-1] \
                    and not re.search(r"return\s+(items|\$input|out|results|result|output)", js):
                warnings.append(f"Code node '{nm}': check it returns items shaped as {{ json: ... }}")

        if t == "n8n-nodes-base.splitInBatches":
            outs = conns.get(nm, {}).get("main", [])
            if len(outs) < 2 or not outs[1]:
                warnings.append(f"Loop Over Items '{nm}': 'loop' output (index 1) is not connected")
        if t == "n8n-nodes-base.webhook" and params.get("responseMode") == "responseNode":
            if not any(x.get("type") == "n8n-nodes-base.respondToWebhook" for x in nodes):
                errors.append(f"Webhook '{nm}' uses responseNode but no Respond to Webhook node exists")
        if t == "n8n-nodes-base.if" and len(conns.get(nm, {}).get("main", [])) < 1:
            warnings.append(f"IF '{nm}' has no outgoing connections")

    # connection integrity
    incoming = Counter()
    for src, outs in conns.items():
        if src not in nameset:
            errors.append(f"connections: source '{src}' is not a node name")
            continue
        for ctype, lists in outs.items():
            if ctype != "main" and ctype not in AI_CONN_TYPES:
                warnings.append(f"connections from '{src}': unusual type '{ctype}'")
            for out_i, targets in enumerate(lists):
                for tgt in targets or []:
                    tn = tgt.get("node")
                    if tn not in nameset:
                        errors.append(f"connections: '{src}' -> '{tn}' targets a node that doesn't exist")
                    else:
                        incoming[tn] += 1
                        if tgt.get("type") != ctype:
                            errors.append(f"connections: '{src}' -> '{tn}' type mismatch ({ctype} vs {tgt.get('type')})")
                        if "index" not in tgt:
                            errors.append(f"connections: '{src}' -> '{tn}' missing 'index'")

    triggers = [n for n in nodes if any(h in n.get("type", "").lower() for h in TRIGGER_HINTS)]
    if not triggers:
        warnings.append("no trigger node found (add Manual/Schedule/Webhook/etc.)")
    for n in nodes:
        if n.get("type", "").endswith("stickyNote") or n in triggers or n.get("disabled"):
            continue
        nm = n["name"]
        is_ai_sub = n.get("type", "").startswith("@n8n/n8n-nodes-langchain.") and nm in conns and \
            any(k in AI_CONN_TYPES for k in conns[nm])
        if incoming[nm] == 0 and not is_ai_sub:
            warnings.append(f"node '{nm}' has no incoming connection (orphan)")

    # resilience hints
    net = [n for n in nodes if any(n.get("type", "").endswith("." + x) for x in NETWORK_TYPES)]
    if net and not wf.get("settings", {}).get("errorWorkflow"):
        has_err_trigger = any(n.get("type") == "n8n-nodes-base.errorTrigger" for n in nodes)
        if not has_err_trigger and not any(n.get("onError") or n.get("retryOnFail") for n in net):
            warnings.append("calls external services but has no retry/onError and no errorWorkflow set; "
                            "mention the Error Workflow setting to the user")
    if not any(n.get("type", "").endswith("stickyNote") for n in nodes) and len(nodes) > 4:
        warnings.append("no sticky note documenting purpose/credentials")

    for e in errors:
        print("ERROR:  ", e)
    for w in warnings:
        print("WARNING:", w)
    print(f"\n{len(nodes)} nodes, {sum(len(t) for o in conns.values() for l in o.values() for t in l)} connections, "
          f"{len(errors)} errors, {len(warnings)} warnings")
    if errors or (strict and warnings):
        sys.exit(1)
    print("OK")


if __name__ == "__main__":
    main()
