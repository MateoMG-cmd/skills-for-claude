#!/usr/bin/env python3
"""
deploy_workflow.py — sube un workflow JSON a una instancia de n8n por la API pública.

Variables de entorno (nunca las incluyas en el JSON ni en el chat):
  N8N_URL       p. ej. https://mi-n8n.ejemplo.com   (sin barra final)
  N8N_API_KEY   creada en Settings > n8n API

Uso:
  python3 deploy_workflow.py flujo.json                 # crea el workflow (inactivo)
  python3 deploy_workflow.py flujo.json --update ID     # reemplaza un workflow existente
  python3 deploy_workflow.py flujo.json --activate      # crea y activa
Solo usa la biblioteca estándar.
"""
import json
import os
import sys
import urllib.error
import urllib.request

ALLOWED = ("name", "nodes", "connections", "settings", "staticData")
ALLOWED_SETTINGS = ("saveExecutionProgress", "saveManualExecutions", "saveDataErrorExecution",
                    "saveDataSuccessExecution", "executionTimeout", "errorWorkflow", "timezone",
                    "executionOrder", "callerPolicy", "callerIds", "timeSavedPerExecution")


def call(method, url, key, body=None):
    req = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"X-N8N-API-KEY": key, "Content-Type": "application/json", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        sys.exit(f"HTTP {e.code} de n8n: {e.read().decode()[:600]}")
    except urllib.error.URLError as e:
        sys.exit(f"No se pudo conectar a n8n: {e.reason}")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    base, key = os.environ.get("N8N_URL", "").rstrip("/"), os.environ.get("N8N_API_KEY")
    if not base or not key:
        sys.exit("Define N8N_URL y N8N_API_KEY en el entorno.")
    with open(argv[1], encoding="utf-8") as f:
        wf = json.load(f)
    body = {k: wf[k] for k in ALLOWED if k in wf}
    body["settings"] = {k: v for k, v in (body.get("settings") or {}).items() if k in ALLOWED_SETTINGS}
    if "--update" in argv:
        wid = argv[argv.index("--update") + 1]
        res = call("PUT", f"{base}/api/v1/workflows/{wid}", key, body)
    else:
        res = call("POST", f"{base}/api/v1/workflows", key, body)
    wid = res.get("id")
    print(f"OK: workflow {wid} -> {base}/workflow/{wid}")
    if "--activate" in argv:
        call("POST", f"{base}/api/v1/workflows/{wid}/activate", key)
        print("Activado.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
