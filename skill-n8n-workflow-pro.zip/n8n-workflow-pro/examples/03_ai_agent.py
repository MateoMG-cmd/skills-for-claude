#!/usr/bin/env python3
"""
Patrón: agente de IA con memoria y herramientas, expuesto por Webhook.
Webhook -> AI Agent (+ modelo, memoria, tool HTTP, parser estructurado) -> Responder

Ejecuta:  python3 03_ai_agent.py salida.json
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from n8n_builder import Workflow

wf = Workflow("Agente - Soporte de pedidos", timezone="America/Mexico_City")

wf.sticky(
    "## Agente de soporte de pedidos\n"
    "Recibe `{ sessionId, mensaje }`, consulta el estado del pedido con una tool y responde.\n\n"
    "**Configurar:** credencial del modelo (Anthropic), Header Auth del Webhook, API de pedidos.\n"
    "**Memoria:** ventana de 10 mensajes por `sessionId` (en producción usa Postgres/Redis; la memoria simple se pierde al reiniciar).\n"
    "**Seguridad:** el agente solo tiene tools de LECTURA; nada que borre o pague.",
    height=260, width=520)

wf.webhook("Recibir mensaje", path="soporte", respond="responseNode", auth="headerAuth")
wf.set("Preparar entrada", {
    "chatInput": "{{ $json.body.mensaje }}",
    "sessionId": "{{ $json.body.sessionId }}",
})
wf.agent("Agente de soporte",
         system_message=("Eres un asistente de soporte de una tienda en línea. Responde en español, breve y amable. "
                         "Para dudas sobre un pedido usa SIEMPRE la herramienta consultar_pedido; no inventes estados. "
                         "Si no tienes el número de pedido, pídelo. Si piden devolver dinero o cambiar datos, "
                         "indica que un humano los contactará."),
         output_parser=True)
wf.chat_model("Modelo Claude", "Agente de soporte", provider="anthropic")
wf.memory("Memoria 10 msgs", "Agente de soporte", session_key="={{ $('Preparar entrada').item.json.sessionId }}")
wf.add("consultar_pedido", "toolHttpRequest",
       {"toolDescription": "Consulta el estado de un pedido. Entrada: número de pedido.",
        "method": "GET",
        "url": "https://api.ejemplo-tienda.com/v1/orders/{order_id}",
        "placeholderDefinitions": {"values": [{"name": "order_id", "description": "Número del pedido", "type": "string"}]},
        "authentication": "genericCredentialType", "genericAuthType": "httpHeaderAuth"},
       credentials=wf.credential("httpHeaderAuth", "API pedidos"))
wf.connect_ai("consultar_pedido", "Agente de soporte", "ai_tool")
wf.add("Formato de salida", "outputParserStructured",
       {"schemaType": "manual",
        "inputSchema": '{"type":"object","properties":{"respuesta":{"type":"string"},'
                       '"necesita_humano":{"type":"boolean"}},"required":["respuesta","necesita_humano"]}'})
wf.connect_ai("Formato de salida", "Agente de soporte", "ai_outputParser")
wf.respond("Responder", body='={{ JSON.stringify($json.output) }}')

wf.chain("Recibir mensaje", "Preparar entrada", "Agente de soporte", "Responder")

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "03_ai_agent.json"
    print("escrito:", wf.save(out))
