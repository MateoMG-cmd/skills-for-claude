#!/usr/bin/env python3
"""
Patrón: API por Webhook con validación, enrutado y respuesta controlada.
Webhook (responseNode) -> validar -> IF -> procesar -> responder 200 | responder 400

Ejecuta:  python3 01_webhook_api.py salida.json
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from n8n_builder import Workflow

wf = Workflow("API - Alta de leads", timezone="America/Mexico_City")

wf.sticky(
    "## API - Alta de leads\n"
    "**Qué hace:** recibe un lead por POST, valida el email, lo guarda en el CRM y responde JSON.\n\n"
    "**Antes de activar**\n"
    "1. Asigna credencial *Header Auth* al Webhook (header `X-API-Key`).\n"
    "2. Asigna credencial al nodo *Guardar en CRM*.\n"
    "3. Enlaza un workflow de errores en Settings > Error workflow.\n\n"
    "**Probar:** `curl -X POST <URL de test> -H 'X-API-Key: ...' -d '{\"email\":\"a@b.com\"}'`",
    height=300, width=520)

wf.webhook("Recibir lead", path="leads", method="POST", respond="responseNode", auth="headerAuth")
wf.set("Normalizar datos", {
    "email": "{{ String($json.body.email || '').trim().toLowerCase() }}",
    "nombre": "{{ $json.body.nombre || '' }}",
    "origen": "{{ $json.body.origen || 'web' }}",
    "recibido_en": "{{ $now.toISO() }}",
})
wf.if_("¿Email válido?", [
    ("{{ $json.email }}", "string", "regex", r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
])
wf.http("Guardar en CRM", "POST", "https://api.ejemplo-crm.com/v1/contacts",
        json_body='={{ JSON.stringify({ email: $json.email, name: $json.nombre, source: $json.origen }) }}',
        auth=("genericCredentialType", "httpHeaderAuth"),
        retry=(3, 2000), on_error="continueErrorOutput")
wf.respond("Responder OK", body='={{ JSON.stringify({ ok: true, id: $json.id }) }}', code=200)
wf.respond("Responder 400", body={"ok": False, "error": "email_invalido"}, code=400)
wf.respond("Responder 502", body={"ok": False, "error": "crm_no_disponible"}, code=502)

wf.chain("Recibir lead", "Normalizar datos", "¿Email válido?")
wf.connect("¿Email válido?", "Guardar en CRM", output=0)      # true
wf.connect("¿Email válido?", "Responder 400", output=1)       # false
wf.connect("Guardar en CRM", "Responder OK", output=0)        # éxito
wf.connect("Guardar en CRM", "Responder 502", output=1)       # salida de error

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "01_webhook_api.json"
    print("escrito:", wf.save(out))
