#!/usr/bin/env python3
"""
Patrón: ETL programado, paginado y por lotes, con workflow de errores enlazado.
Schedule -> obtener (paginado) -> filtrar nuevos -> lotes -> enviar -> resumen

Genera DOS archivos: el flujo principal y el workflow de errores (Error Trigger -> Slack).
Tras importar el de errores, copia su ID en Settings > Error workflow del principal.

Ejecuta:  python3 02_scheduled_etl.py carpeta_salida/
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from n8n_builder import Workflow, rl

# ---------------- workflow de errores (reutilizable por todos los flujos) ----------------
err = Workflow("Global - Alerta de errores")
err.error_trigger("Error Trigger")
err.set("Armar mensaje", {
    "texto": "{{ '🔴 Falló: ' + $json.workflow.name + '\\nNodo: ' + ($json.execution.lastNodeExecuted || 'n/d') + "
             "'\\nError: ' + ($json.execution.error.message || 'desconocido') + '\\nEjecución: ' + $json.execution.url }}",
})
err.add("Avisar por Slack", "n8n-nodes-base.slack",
        {"resource": "message", "operation": "post", "select": "channel",
         "channelId": rl("REEMPLAZAR_ID_CANAL", "id"), "text": "={{ $json.texto }}", "otherOptions": {}},
        version=2.3, credentials=err.credential("slackApi", "Slack account"))
err.chain("Error Trigger", "Armar mensaje", "Avisar por Slack")

# ---------------- flujo principal ----------------
wf = Workflow("ETL - Pedidos a almacén (cada hora)", timezone="America/Mexico_City",
              error_workflow="REEMPLAZAR_ID_WORKFLOW_ERRORES")

wf.sticky(
    "## ETL horario de pedidos\n"
    "Trae pedidos nuevos de la tienda (API paginada), descarta los ya enviados y los manda al almacén en lotes de 20.\n\n"
    "**Configurar:** credenciales de tienda y almacén; ID del workflow de errores en Settings.\n"
    "**Idempotencia:** el filtro usa `pedido_id` contra los ya procesados (Data Table / BD).",
    height=240, width=520)

wf.schedule("Cada hora", every_hours=1)
wf.http("Obtener pedidos", "GET", "https://api.ejemplo-tienda.com/v1/orders",
        query={"status": "paid", "updated_since": "={{ $now.minus({hours: 1}).toISO() }}", "per_page": "100"},
        auth=("genericCredentialType", "httpHeaderAuth"),
        pagination={"pagination": {
            "paginationMode": "responseContainsNextURL",
            "nextURL": "={{ $response.body.links.next }}",
            "paginationCompleteWhen": "other",
            "completeExpression": "={{ !$response.body.links.next }}",
            "limitPagesFetched": True, "maxRequests": 20}},
        retry=(3, 3000))
wf.add("Separar pedidos", "splitOut", {"fieldToSplitOut": "data", "options": {}})
wf.filter("Solo no enviados", [("{{ $json.shipped_to_warehouse }}", "boolean", "false")])
wf.split_batches("Lotes de 20", size=20)
wf.http("Enviar a almacén", "POST", "https://api.ejemplo-almacen.com/v1/shipments",
        json_body='={{ JSON.stringify({ order_id: $json.id, items: $json.line_items, address: $json.shipping }) }}',
        auth=("genericCredentialType", "httpHeaderAuth"),
        retry=(3, 2000), batch=(5, 1000), on_error="continueErrorOutput")
wf.code("Registrar fallo", "return $input.all().map(i => ({ json: { order_id: i.json.id ?? null, "
        "error: i.json.error?.message ?? 'error desconocido' } }));")
wf.code("Resumen", "const total = $('Solo no enviados').all().length;\n"
        "return [{ json: { total, enviados_ok: $('Enviar a almacén').all().length } }];")

wf.chain("Cada hora", "Obtener pedidos", "Separar pedidos", "Solo no enviados", "Lotes de 20")
wf.connect("Lotes de 20", "Resumen", output=0)                 # done
wf.connect("Lotes de 20", "Enviar a almacén", output=1)        # loop
wf.connect("Enviar a almacén", "Lotes de 20", output=0)        # volver al bucle
wf.connect("Enviar a almacén", "Registrar fallo", output=1)    # salida de error
wf.connect("Registrar fallo", "Lotes de 20")

if __name__ == "__main__":
    outdir = sys.argv[1] if len(sys.argv) > 1 else "."
    os.makedirs(outdir, exist_ok=True)
    print("escrito:", err.save(os.path.join(outdir, "global-errores.json")))
    print("escrito:", wf.save(os.path.join(outdir, "etl-pedidos.json")))
