# n8n workflow JSON format

## Contents
1. Top-level shape
2. Node object
3. Connections
4. Branching nodes (IF, Switch, Loop)
5. AI sub-node connections
6. Layout
7. Minimal complete example
8. Import gotchas

## 1. Top-level shape
```json
{
  "name": "Descriptive workflow name",
  "nodes": [ ... ],
  "connections": { ... },
  "active": false,
  "settings": { "executionOrder": "v1", "timezone": "America/Mexico_City", "errorWorkflow": "<id, optional>" },
  "pinData": {},
  "meta": { "templateCredsSetupCompleted": false },
  "tags": []
}
```
Keep `active: false` so the user tests before activating. `executionOrder: "v1"` is the modern default. `errorWorkflow` requires the ID of an existing workflow, so usually leave it out and tell the user to set it in Workflow Settings.

## 2. Node object
```json
{
  "id": "b1f0c1de-0000-4000-8000-000000000001",
  "name": "Get open invoices",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [460, 300],
  "parameters": { },
  "credentials": { "httpHeaderAuth": { "id": "REPLACE_ME", "name": "My API key" } },
  "disabled": false,
  "notes": "optional",
  "notesInFlow": false,
  "retryOnFail": true, "maxTries": 3, "waitBetweenTries": 2000,
  "onError": "continueErrorOutput",
  "alwaysOutputData": false,
  "executeOnce": false
}
```
- `id`: unique UUID v4-like string per node.
- `type`: `n8n-nodes-base.<name>` for core/integration nodes, `@n8n/n8n-nodes-langchain.<name>` for AI nodes.
- `onError`: `"stopWorkflow"` (default, omit), `"continueRegularOutput"`, `"continueErrorOutput"` (adds a second output for the error branch).
- `credentials` key is the credential *type* name, which varies per node (`slackApi`, `googleSheetsOAuth2Api`, `httpHeaderAuth`, `openAiApi`, `postgres`…).
- Sticky notes: `type: "n8n-nodes-base.stickyNote"`, `typeVersion: 1`, parameters `{ "content": "markdown", "height": 200, "width": 400, "color": 4 }`; they have no connections.

## 3. Connections
Keyed by **source node name** → output type → list per output index → list of targets:
```json
"connections": {
  "Webhook": { "main": [ [ { "node": "Validate input", "type": "main", "index": 0 } ] ] },
  "Validate input": { "main": [
      [ { "node": "Create record", "type": "main", "index": 0 } ],
      [ { "node": "Respond 400",   "type": "main", "index": 0 } ]
  ] }
}
```
Outer array index = source output index; inner array = fan-out targets from that output. An empty `[]` is a valid unused output. `index` on the target is the input index (Merge uses 0 and 1).

## 4. Branching nodes
- **IF** (v2.x): output 0 = true, output 1 = false.
- **Switch**: one output per rule, plus fallback when enabled.
- **Split In Batches / Loop Over Items** (`splitInBatches` v3): output 0 = **done**, output 1 = **loop**. The last node inside the loop connects *back* to the Loop node input. Nodes after the loop connect from output 0.
- **Continue (error output)**: output 0 success, output 1 error.
- **Merge**: inputs 0 and 1 (and more in v3); set mode (`append`, `combine` by fields/position, `chooseBranch`).

## 5. AI sub-node connections
Language-model, memory, tool, parser and embedding nodes connect **into** the agent/chain using special types, with the sub-node as the source:
```json
"OpenAI Chat Model": { "ai_languageModel": [ [ { "node": "AI Agent", "type": "ai_languageModel", "index": 0 } ] ] },
"Window Buffer Memory": { "ai_memory": [ [ { "node": "AI Agent", "type": "ai_memory", "index": 0 } ] ] },
"Calculator": { "ai_tool": [ [ { "node": "AI Agent", "type": "ai_tool", "index": 0 } ] ] }
```
Other types: `ai_outputParser`, `ai_embedding`, `ai_vectorStore`, `ai_document`, `ai_textSplitter`, `ai_retriever`.

## 6. Layout
Position is `[x, y]`. Space columns ~220–260 px, rows ~120–160 px. Main flow on y≈300; branches offset ±140 in y; sticky note above at y≈80, left aligned with the first node. AI sub-nodes sit below their agent (y + ~220).

## 7. Minimal complete example (webhook → validate → respond)
```json
{
  "name": "Lead intake",
  "nodes": [
    { "id": "11111111-1111-4111-8111-111111111111", "name": "Webhook", "type": "n8n-nodes-base.webhook", "typeVersion": 2,
      "position": [240, 300],
      "parameters": { "httpMethod": "POST", "path": "lead-intake", "responseMode": "responseNode", "options": {} },
      "webhookId": "22222222-2222-4222-8222-222222222222" },
    { "id": "33333333-3333-4333-8333-333333333333", "name": "Has valid email?", "type": "n8n-nodes-base.if", "typeVersion": 2.2,
      "position": [480, 300],
      "parameters": { "conditions": { "options": { "caseSensitive": true, "leftValue": "", "typeValidation": "strict" },
        "conditions": [ { "id": "c1", "leftValue": "={{ $json.body.email }}", "rightValue": "", "operator": { "type": "string", "operation": "regex" } } ],
        "combinator": "and" } } },
    { "id": "44444444-4444-4444-8444-444444444444", "name": "Respond OK", "type": "n8n-nodes-base.respondToWebhook", "typeVersion": 1.1,
      "position": [720, 220], "parameters": { "respondWith": "json", "responseBody": "={{ { \"ok\": true } }}", "options": { "responseCode": 200 } } },
    { "id": "55555555-5555-4555-8555-555555555555", "name": "Respond 400", "type": "n8n-nodes-base.respondToWebhook", "typeVersion": 1.1,
      "position": [720, 400], "parameters": { "respondWith": "json", "responseBody": "={{ { \"ok\": false, \"error\": \"invalid email\" } }}", "options": { "responseCode": 400 } } }
  ],
  "connections": {
    "Webhook": { "main": [ [ { "node": "Has valid email?", "type": "main", "index": 0 } ] ] },
    "Has valid email?": { "main": [ [ { "node": "Respond OK", "type": "main", "index": 0 } ], [ { "node": "Respond 400", "type": "main", "index": 0 } ] ] }
  },
  "active": false,
  "settings": { "executionOrder": "v1" }
}
```
(The IF regex operator needs a real pattern in `rightValue` — fill it in, e.g. `^[^@\s]+@[^@\s]+\.[^@\s]+$`. Use the simplest operator that fits; when unsure of the IF condition schema, prefer a Code/Set-based boolean plus an IF on `{{ $json.valid }}` with the `boolean true` operator.)

## 8. Import gotchas
- Wrong/unknown `type` → node shows as "?" and workflow fails to import cleanly. Only use node types you are sure exist.
- `typeVersion` higher than the user's instance supports → "node not installed / version unsupported". If the user's instance is old, lower it.
- Connection keys that don't match a node `name` exactly (case, spaces) silently drop the link. Run the validator.
- Webhook nodes need a `webhookId`; n8n regenerates it on import if missing, but providing one is harmless.
- Credentials with unknown IDs import fine but must be re-selected by the user; say so.
