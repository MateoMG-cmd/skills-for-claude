# Expressions and the Code node

## Expressions
In workflow JSON a parameter is an expression only if the string starts with `=`: `"={{ $json.email }}"`. Mixed text works too: `"=Hola {{ $json.name }}"`. Without `=`, `{{ }}` is literal text.

| Need | Expression |
|---|---|
| Field of current item | `{{ $json.field }}`, `{{ $json["field with space"] }}` |
| Nested / array | `{{ $json.user.emails[0] }}` |
| Data from earlier node, same item lineage | `{{ $('Node name').item.json.id }}` |
| First / last / all items of a node | `$('Node').first().json.x`, `.last()`, `.all()` |
| Current node's input | `$input.all()`, `$input.first()`, `$input.item` |
| Index of current item | `{{ $itemIndex }}` |
| Now / today (workflow timezone) | `{{ $now }}`, `{{ $today }}`; Luxon: `{{ $now.minus({days: 1}).toISO() }}` |
| Format date | `{{ $now.toFormat('yyyy-LL-dd') }}` |
| Execution info | `{{ $execution.id }}`, `{{ $execution.resumeUrl }}`, `{{ $workflow.name }}` |
| Env var (if allowed) | `{{ $env.MY_VAR }}` — may be blocked by default in newer versions; prefer credentials or workflow variables |
| Ternary / default | `{{ $json.qty > 0 ? 'ok' : 'empty' }}`, `{{ $json.name ?? 'N/A' }}` |
| Build an object | `{{ { a: $json.a, b: 1 } }}` |
| JSON string | `{{ JSON.stringify($json) }}` |
| Safe access | `{{ $json.a?.b?.c }}` |

Helpers: `.isEmpty()`, `.isNotEmpty()`, `.toLowerCase()`, `.split(',')`, `.toNumber()`, array `.pluck()`, `.unique()`, `.sum()`; `$jmespath(obj, 'path')`.

**Item linking:** `.item` follows the paired item through nodes. It breaks after Code nodes that create new items, Aggregate, or Merge by position — then use `.first()`, `.all()` or carry the needed field forward in the data. "Can't determine which item to use" errors mean this.

**Types:** expression results in a typed field must match (number vs string). IF/Filter with strict type validation fails on `"5"` vs `5`; convert with `.toNumber()` or Edit Fields type.

## Code node (JavaScript)
Two modes:
- **Run Once for All Items** (default): read `$input.all()`, return an **array** of `{ json: {...} }`.
- **Run Once for Each Item**: read `$input.item.json`, return **one** `{ json: {...} }`.

```js
// All items mode
const out = [];
for (const item of $input.all()) {
  const d = item.json;
  out.push({ json: { ...d, fullName: `${d.first} ${d.last}`.trim(), total: Number(d.qty) * Number(d.price) } });
}
return out;
```
```js
// Each item mode
return { json: { ...$json, email: ($json.email || '').toLowerCase() } };
```
Rules that avoid common errors:
- Always return the `json` wrapper; returning raw objects or `undefined` errors out. Return `[]` to emit nothing.
- Binary data: keep `binary` on the returned item (`{ json, binary: item.binary }`).
- Reference other nodes with `$('Node name').all()`.
- No `require` of arbitrary npm modules on Cloud; on self-hosted only if `NODE_FUNCTION_ALLOW_EXTERNAL` allows. Built-ins like `luxon` (`DateTime`), `$jmespath`, `$helpers.httpRequest(...)` are available. Prefer native nodes over fetching in Code.
- No top-level `await` issues: the code is wrapped in an async function, so `await $helpers.httpRequest({...})` works.
- Use `console.log` for debugging (visible in browser console/logs); remove noisy logs afterwards.
- Throw `new Error('clear message')` for fatal validation failures; the error workflow will pick it up.
- Python mode exists (Pyodide / native task runner); stick to JavaScript unless the user wants Python, because capabilities and speed differ.

## When to use which node instead of Code
| Task | Prefer |
|---|---|
| Rename/set/convert fields | Edit Fields (Set) |
| Filter rows | Filter / IF |
| Dedupe | Remove Duplicates |
| Group/sum/count | Summarize / Aggregate |
| Join two datasets | Merge (combine by field) |
| One item → many (array field) | Split Out |
| Many → one (array) | Aggregate |
| Sort / limit | Sort / Limit |
| Date math | Date & Time node |
| Regex extraction / complex reshaping / algorithms | Code |

## Data shape reminders
- Every node passes an **array of items**; most nodes run once per item. 100 items into an HTTP Request = 100 calls (use batching options or aggregate first).
- An empty output stops the branch silently; enable **Always Output Data** where you need a downstream "nothing found" path.
- Webhook payload sits under `$json.body`, query under `$json.query`, headers under `$json.headers`.
