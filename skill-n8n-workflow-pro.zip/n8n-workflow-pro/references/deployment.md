# Importar, desplegar y operar

Contenido: importar por UI · desplegar por API pública · pasos tras importar · entregables · versiones de n8n.

## Importar por la interfaz

1. Descargar el `.json` entregado.
2. En n8n: menú del lienzo `⋯` → **Import from file…** (o pegar el JSON con Ctrl/Cmd+V sobre el lienzo vacío — vale también para un trozo de nodos).
3. Asignar credenciales: cada nodo con credencial pendiente muestra un aviso; abrir el nodo → elegir/crear la credencial.
4. Reemplazar placeholders (`REEMPLAZAR_*`): IDs de canal/hoja/workflow de errores, URLs.
5. **Probar** con "Execute workflow" (datos reales de prueba), luego **activar**.
6. Enlazar el workflow de errores: ⋯ → Settings → *Error workflow*.

Si hay varios archivos (flujo + workflow de errores + sub-workflows): importar primero los de apoyo, anotar sus IDs (aparecen en la URL del editor `/workflow/<ID>`), y completar `Execute Workflow` / `errorWorkflow` en los demás.

## Desplegar por API pública (self-hosted o Cloud con API key)

Crear una API key en *Settings → n8n API*. Luego:

```bash
curl -X POST "$N8N_URL/api/v1/workflows" \
  -H "X-N8N-API-KEY: $N8N_API_KEY" -H "Content-Type: application/json" \
  --data @flujo.json
```
La respuesta incluye el `id`. Activar: `POST /api/v1/workflows/{id}/activate`. Actualizar: `PUT /api/v1/workflows/{id}` (envía name/nodes/connections/settings completos). El script `scripts/deploy_workflow.py` hace esto leyendo `N8N_URL` y `N8N_API_KEY` del entorno (nunca las pidas ni las guardes en el JSON). Solo ofrécelo si el usuario lo pide o tiene acceso de red a su instancia; desde el sandbox de Claude normalmente no hay salida a su servidor, así que por defecto entrega el archivo.

Formato aceptado por la API: solo `name`, `nodes`, `connections`, `settings` (+ `staticData` opcional). Lo demás se rechaza (ver `workflow-json-spec.md`).

## Qué debe contener la respuesta final (al usuario)

1. Archivo(s) `.json` (con `SendUserFile`/presentación de archivos) — y NO un volcado del JSON en el chat salvo que el flujo sea diminuto.
2. Mapa del flujo en 1–3 líneas.
3. **Antes de activar**: lista corta (credenciales por tipo, placeholders, ID del workflow de errores).
4. **Cómo probar**: payload/curl y resultado esperado.
5. **Supuestos** que hiciste y decisiones de diseño relevantes (1–3 puntos).
6. Una mejora siguiente opcional (no un menú de diez).

## Compatibilidad de versiones

| Tema | n8n 1.x | n8n 2.x |
|---|---|---|
| Code node | corre en el proceso principal; `$env` posible | task runners por defecto; `$env`/`process.env` bloqueados salvo configuración |
| Python en Code | Pyodide | solo task runner externo (imagen `n8nio/runners`) |
| Execute Command / Local File Trigger | habilitados | **deshabilitados por defecto** |
| Nodo Start | existe (legado) | eliminado → Manual Trigger |
| Edición de flujos activos | guardar = publicar al instante | guardado automático como borrador; se publica explícitamente |

Si el usuario no dice qué versión usa, genera flujos compatibles con ambas (sin `$env`, sin Execute Command, sin Python, sin Start) y menciónalo.

## Mantenimiento

- Duplicar antes de cambios grandes; usar el historial de versiones de n8n.
- Etiquetas (tags) por área/entorno (se asignan en la UI; no van en el JSON de la API).
- Revisar la pestaña *Executions* tras activar; configurar la alerta global de errores el primer día.
- Entornos dev/prod: variables `$vars` o credenciales distintas por entorno, mismos flujos.
