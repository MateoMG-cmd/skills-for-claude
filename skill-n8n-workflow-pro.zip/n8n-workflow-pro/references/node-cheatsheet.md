# Node cheatsheet (types, typical versions, key parameters)

Versions below are typical for current n8n; if the user's instance is older, lower them. When unsure about a parameter name for a specific integration node (Google Sheets, Notion, Slack…), those schemas change between versions: build the node with the parameters you are confident about, and tell the user which fields to confirm in the UI. If you cannot access docs, prefer the generic **HTTP Request** node with the vendor's documented REST API for exactness.

## Triggers
| Node | type | ver | Notes |
|---|---|---|---|
| Manual Trigger | `n8n-nodes-base.manualTrigger` | 1 | for tests/sub-flows |
| Schedule Trigger | `n8n-nodes-base.scheduleTrigger` | 1.2 | `rule.interval: [{field:"hours",hoursInterval:1}]` or `{field:"cronExpression",expression:"0 9 * * 1-5"}` |
| Webhook | `n8n-nodes-base.webhook` | 2 | `httpMethod`, `path`, `responseMode` (`onReceived`/`lastNode`/`responseNode`), `authentication` |
| Execute Workflow Trigger | `n8n-nodes-base.executeWorkflowTrigger` | 1.1 | sub-workflow entry |
| Error Trigger | `n8n-nodes-base.errorTrigger` | 1 | error workflows |
| Form Trigger | `n8n-nodes-base.formTrigger` | 2.x | hosted forms |
| Chat Trigger | `@n8n/n8n-nodes-langchain.chatTrigger` | 1.x | chat UI for agents |
| Email (IMAP) Trigger | `n8n-nodes-base.emailReadImap` | 2 | |

## Logic / data
| Node | type | ver | Key params |
|---|---|---|---|
| Edit Fields (Set) | `n8n-nodes-base.set` | 3.4 | `assignments.assignments:[{id,name,value,type}]`, `includeOtherFields` |
| IF | `n8n-nodes-base.if` | 2.2 | `conditions` (see format doc) |
| Switch | `n8n-nodes-base.switch` | 3.2 | `rules.values[]`, `options.fallbackOutput` |
| Filter | `n8n-nodes-base.filter` | 2.2 | same condition schema as IF |
| Merge | `n8n-nodes-base.merge` | 3 | `mode`, `joinMode`, `fieldsToMatchString` |
| Split Out | `n8n-nodes-base.splitOut` | 1 | `fieldToSplitOut` |
| Aggregate | `n8n-nodes-base.aggregate` | 1 | `aggregate: "aggregateIndividualFields"` |
| Summarize | `n8n-nodes-base.summarize` | 1.1 | group-by & sum/count |
| Sort / Limit | `n8n-nodes-base.sort` / `.limit` | 1 / 1 | |
| Remove Duplicates | `n8n-nodes-base.removeDuplicates` | 2 | operations incl. previous executions |
| Loop Over Items | `n8n-nodes-base.splitInBatches` | 3 | `batchSize`; outputs: 0 done, 1 loop |
| Wait | `n8n-nodes-base.wait` | 1.1 | `resume: timeInterval/webhook/form`, `amount`, `unit` |
| Code | `n8n-nodes-base.code` | 2 | `mode: runOnceForAllItems/runOnceForEachItem`, `jsCode` |
| Date & Time | `n8n-nodes-base.dateTime` | 2 | |
| Stop and Error | `n8n-nodes-base.stopAndError` | 1 | `errorMessage` |
| No Operation | `n8n-nodes-base.noOp` | 1 | join/readability |
| Execute Workflow | `n8n-nodes-base.executeWorkflow` | 1.2 | `workflowId`, `source: database` |
| Respond to Webhook | `n8n-nodes-base.respondToWebhook` | 1.1 | `respondWith`, `responseBody`, `options.responseCode` |

## Network
**HTTP Request** `n8n-nodes-base.httpRequest` v4.2: `method`, `url`, `authentication: "genericCredentialType"` + `genericAuthType: "httpHeaderAuth"` (or `predefinedCredentialType` + `nodeCredentialType`), `sendQuery/queryParameters.parameters:[{name,value}]`, `sendHeaders`, `sendBody` + `contentType: "json"` + `specifyBody: "json"` + `jsonBody`, `options`: `{batching:{batch:{batchSize,batchInterval}}, pagination:{...}, timeout, response:{response:{neverError, fullResponse}}}`. Use `neverError` only when you handle status codes yourself.

## Common integrations (types)
Slack `n8n-nodes-base.slack`; Gmail `n8n-nodes-base.gmail`; Google Sheets `n8n-nodes-base.googleSheets` (v4.x; resource/operation, `documentId`, `sheetName` as resource-locator objects `{ "__rl": true, "value": "...", "mode": "id" }`); Google Drive `googleDrive`; Notion `notion`; Airtable `airtable`; Telegram `telegram`; WhatsApp Business `whatsApp`; Postgres `postgres`; MySQL `mySql`; MongoDB `mongoDb`; Supabase `supabase`; Stripe `stripe`; HubSpot `hubspot`; Discord `discord`; Microsoft Outlook `microsoftOutlook`; Twilio `twilio`; S3 `awsS3`; Redis `redis`; GitHub `github`; Jira `jira`; Data Table `dataTable` (built-in storage on recent versions).
Resource-locator fields (`__rl`) are the norm in newer node versions: `{ "__rl": true, "value": "<id>", "mode": "id" }`; mode `list` also needs `cachedResultName`.

## Binary / files
Read/Write Files, **Extract From File** (`extractFromFile`), **Convert to File** (`convertToFile`), Compression. Binary lives under `item.binary.<propName>` (default `data`). Webhook file uploads arrive as binary props.
