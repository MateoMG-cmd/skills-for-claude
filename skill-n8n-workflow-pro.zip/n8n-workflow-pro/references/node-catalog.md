# Catálogo de nodos: tipo, typeVersion seguro y forma de `parameters`

Contenido: triggers · lógica/flujo · transformación de datos · HTTP · integraciones frecuentes · IA · cómo manejar nodos que no están aquí.

> **Versiones.** Las `typeVersion` de abajo son conservadoras (funcionan en n8n 1.x reciente y 2.x). Si el usuario te pega un nodo exportado de SU instancia, copia su `typeVersion` y estructura: es la fuente de verdad. Para parámetros de integraciones propias (Gmail, Sheets, Notion…) la forma exacta cambia entre versiones; si dudas, usa HTTP Request contra la API oficial (estable y documentada) o avisa de qué nodo hay que revisar al abrirlo.

## Triggers

| Nodo | type | v | parameters clave |
|---|---|---|---|
| Manual | `n8n-nodes-base.manualTrigger` | 1 | `{}` |
| Schedule | `n8n-nodes-base.scheduleTrigger` | 1.2 | `{"rule":{"interval":[{"field":"cron","expression":"0 8 * * 1-5"}]}}` · `{"field":"hours","hoursInterval":1}` · `{"field":"minutes","minutesInterval":15}` · `{"field":"days","daysInterval":1,"triggerAtHour":8}` |
| Webhook | `n8n-nodes-base.webhook` | 2 | `{"httpMethod":"POST","path":"mi-ruta","responseMode":"responseNode","authentication":"headerAuth","options":{}}` + `webhookId` + credencial `httpHeaderAuth` |
| Error Trigger | `n8n-nodes-base.errorTrigger` | 1 | `{}` (solo corre por ejecuciones de producción, no por pruebas manuales) |
| Sub-workflow | `n8n-nodes-base.executeWorkflowTrigger` | 1.1 | `{"inputSource":"passthrough"}` |
| Chat | `@n8n/n8n-nodes-langchain.chatTrigger` | 1.1 | `{"options":{}}` + `webhookId` |
| Form | `n8n-nodes-base.formTrigger` | 2.2 | `{"formTitle":"..","formFields":{"values":[{"fieldLabel":"Email","fieldType":"email","requiredField":true}]},"options":{}}` |

Webhook: la URL de prueba es `/webhook-test/<path>`, la de producción `/webhook/<path>` (solo tras activar). Datos en `$json.body`, `$json.headers`, `$json.query`.

## Lógica y control de flujo

**IF** `n8n-nodes-base.if` v2.2 — salida 0=true, 1=false.
```json
{"conditions":{"options":{"caseSensitive":true,"leftValue":"","typeValidation":"strict","version":2},
 "conditions":[{"id":"uuid","leftValue":"={{ $json.status }}","rightValue":"active",
                "operator":{"type":"string","operation":"equals"}}],"combinator":"and"},"options":{}}
```
Operadores — string: `equals, notEquals, contains, notContains, startsWith, endsWith, regex, empty, notEmpty` · number: `equals, notEquals, gt, lt, gte, lte` · boolean: `true, false` · dateTime: `after, before, equals` · array: `contains, lengthEquals, empty` · object: `exists, empty`. Los unarios (`empty`, `notEmpty`, `true`, `false`, `exists`) llevan `"singleValue": true` en `operator`. `typeValidation: "loose"` evita errores cuando llegan números como string.

**Filter** `n8n-nodes-base.filter` v2.2 — misma estructura `conditions`; deja pasar solo los items que cumplen.

**Switch** `n8n-nodes-base.switch` v3.2
```json
{"rules":{"values":[{"conditions":{...igual que IF...},"renameOutput":true,"outputKey":"Urgente"}]},
 "options":{"fallbackOutput":"extra"}}
```
Salidas en orden de reglas; con `fallbackOutput: "extra"` la última salida es el "else".

**Merge** `n8n-nodes-base.merge` v3.1 — dos entradas. `{}` = append. Combinar por campo: `{"mode":"combine","combineBy":"combineByFields","fieldsToMatchString":"id","joinMode":"keepMatches","options":{}}` · por posición: `"combineBy":"combineByPosition"`. Un Merge espera a que ambas ramas terminen; si una rama puede quedar vacía, el Merge no avanza (usar `alwaysOutputData` en el nodo que puede devolver vacío).

**Split In Batches (Loop Over Items)** `n8n-nodes-base.splitInBatches` v3 — `{"batchSize":10,"options":{}}`. **Salida 0 = done, salida 1 = loop.** El último nodo del cuerpo se conecta de vuelta al SplitInBatches. Olvidar la vuelta = solo se procesa el primer lote.

**Wait** `n8n-nodes-base.wait` v1.1 — `{"resume":"timeInterval","amount":30,"unit":"seconds"}`; también `webhook` (reanuda con llamada externa) y `specificTime`. Con waits largos la ejecución se guarda en BD y se reanuda.

**Execute Workflow** `n8n-nodes-base.executeWorkflow` v1.2 — `{"source":"database","workflowId":{"__rl":true,"value":"ID","mode":"id"},"options":{"waitForSubWorkflow":true}}`. El destino empieza con *Execute Workflow Trigger*.

**No Operation** `n8n-nodes-base.noOp` v1 — para ramas que "no hacen nada" a propósito (más legible que dejar la salida colgando).

**Respond to Webhook** `n8n-nodes-base.respondToWebhook` v1.1 — `{"respondWith":"json","responseBody":"={{ JSON.stringify({ok:true}) }}","options":{"responseCode":200}}`. Requiere `responseMode:"responseNode"` en el Webhook. Todas las ramas del flujo deben terminar en un Respond (si no, el cliente se queda esperando hasta timeout).

## Transformación de datos

**Edit Fields (Set)** `n8n-nodes-base.set` v3.4
```json
{"assignments":{"assignments":[{"id":"uuid","name":"email","value":"={{ $json.body.email }}","type":"string"}]},
 "includeOtherFields":false,"options":{}}
```
`type`: `string|number|boolean|object|array`. Para object/array el `value` es un string JSON o expresión.

**Code** `n8n-nodes-base.code` v2 — `{"jsCode":"...","mode":"runOnceForAllItems"}` (default) o `"runOnceForEachItem"`. Ver `expressions-and-code.md`.

**Split Out** `n8n-nodes-base.splitOut` v1 — `{"fieldToSplitOut":"data","options":{}}`: convierte un array en un campo en N items.
**Aggregate** `n8n-nodes-base.aggregate` v1 — `{"aggregate":"aggregateAllItemData","options":{}}`: N items → 1 item con array.
**Summarize** `n8n-nodes-base.summarize` v1.1 — sumas/conteos/agrupaciones sin código.
**Sort** `n8n-nodes-base.sort` v1 · **Limit** `n8n-nodes-base.limit` v1 · **Remove Duplicates** `n8n-nodes-base.removeDuplicates` v2 · **Date & Time** `n8n-nodes-base.dateTime` v2.
**Convert to File / Extract From File** — para CSV/XLSX/PDF/JSON ↔ binario.

Prefiere estos nodos sobre Code cuando existan: son visibles, depurables y no requieren task runner.

## HTTP Request (`n8n-nodes-base.httpRequest` v4.2)

```json
{"method":"POST","url":"https://api.ejemplo.com/v1/items",
 "authentication":"predefinedCredentialType","nodeCredentialType":"slackApi",
 "sendHeaders":true,"headerParameters":{"parameters":[{"name":"X-Foo","value":"bar"}]},
 "sendQuery":true,"queryParameters":{"parameters":[{"name":"page","value":"1"}]},
 "sendBody":true,"contentType":"json","specifyBody":"json","jsonBody":"={{ JSON.stringify({a:1}) }}",
 "options":{"timeout":30000,
   "batching":{"batch":{"batchSize":5,"batchInterval":1000}},
   "response":{"response":{"responseFormat":"json"}},
   "pagination":{"pagination":{"paginationMode":"responseContainsNextURL",
       "nextURL":"={{ $response.body.next }}","paginationCompleteWhen":"other",
       "completeExpression":"={{ !$response.body.next }}","limitPagesFetched":true,"maxRequests":20}}}}
```
- Auth propia: `"authentication":"genericCredentialType","genericAuthType":"httpHeaderAuth"` (o `httpBasicAuth`, `httpBearerAuth`, `oAuth2Api`).
- Siempre: `timeout`, `retryOnFail` (3 intentos, 2000 ms) y, si la API tiene rate limit, `batching`.
- Paginación: pon un tope (`maxRequests`) para evitar bucles infinitos.
- Binarios: `"responseFormat":"file"` y `"outputPropertyName":"data"`.
- Para `jsonBody` usa `JSON.stringify({...})` dentro de la expresión: evita errores de comillas/escape con datos del usuario.

## Integraciones frecuentes (formas orientativas; verificar al abrir)

| Servicio | type | v | credencial | parameters base |
|---|---|---|---|---|
| Slack (mensaje) | `n8n-nodes-base.slack` | 2.3 | `slackApi` / `slackOAuth2Api` | `{"resource":"message","operation":"post","select":"channel","channelId":{"__rl":true,"value":"C0123","mode":"id"},"text":"=...","otherOptions":{}}` |
| Gmail (enviar) | `n8n-nodes-base.gmail` | 2.1 | `gmailOAuth2` | `{"resource":"message","operation":"send","sendTo":"a@b.com","subject":"..","emailType":"text","message":"..","options":{}}` |
| Google Sheets (append) | `n8n-nodes-base.googleSheets` | 4.5 | `googleSheetsOAuth2Api` | `{"operation":"append","documentId":{"__rl":true,"value":"ID","mode":"id"},"sheetName":{"__rl":true,"value":"Hoja 1","mode":"name"},"columns":{"mappingMode":"autoMapInputData","value":{},"matchingColumns":[]},"options":{}}` (`appendOrUpdate` exige `matchingColumns`) |
| Telegram | `n8n-nodes-base.telegram` | 1.2 | `telegramApi` | `{"chatId":"123","text":"=...","additionalFields":{}}` |
| Postgres | `n8n-nodes-base.postgres` | 2.5 | `postgres` | `{"operation":"executeQuery","query":"SELECT * FROM t WHERE id = $1","options":{"queryReplacement":"={{ $json.id }}"}}` — usa SIEMPRE parámetros (`$1`) y `queryReplacement`, nunca concatenes datos en el SQL |
| Email SMTP | `n8n-nodes-base.emailSend` | 2.1 | `smtp` | `{"fromEmail":"..","toEmail":"..","subject":"..","emailFormat":"text","text":".."}` |

## IA (LangChain) — resumen; detalle en `ai-agents.md`

| Nodo | type | v |
|---|---|---|
| AI Agent | `@n8n/n8n-nodes-langchain.agent` | 2.2 |
| Basic LLM Chain | `@n8n/n8n-nodes-langchain.chainLlm` | 1.5 |
| Modelo Anthropic | `@n8n/n8n-nodes-langchain.lmChatAnthropic` | 1.3 |
| Modelo OpenAI | `@n8n/n8n-nodes-langchain.lmChatOpenAi` | 1.2 |
| Window Buffer Memory | `@n8n/n8n-nodes-langchain.memoryBufferWindow` | 1.3 |
| Postgres Chat Memory | `@n8n/n8n-nodes-langchain.memoryPostgresChat` | 1.3 |
| Structured Output Parser | `@n8n/n8n-nodes-langchain.outputParserStructured` | 1.3 |
| Tool HTTP Request | `@n8n/n8n-nodes-langchain.toolHttpRequest` | 1.1 |
| Tool Workflow | `@n8n/n8n-nodes-langchain.toolWorkflow` | 2.2 |
| Text Classifier | `@n8n/n8n-nodes-langchain.textClassifier` | 1.1 |
| Information Extractor | `@n8n/n8n-nodes-langchain.informationExtractor` | 1.2 |

## Nodos que no están en esta tabla

1. ¿Existe como API HTTP documentada? → usa **HTTP Request** (siempre importa bien).
2. ¿El usuario puede copiar un nodo de su lienzo? → pídele que pegue ese JSON y úsalo de plantilla (en n8n: seleccionar nodo → Ctrl/Cmd+C).
3. Si usas el tipo de memoria, indica en una Sticky Note y en la respuesta: "revisa el nodo X al abrirlo; la estructura de sus parámetros depende de la versión".
4. Si hay un MCP de n8n conectado (p. ej. n8n-mcp), úsalo para consultar el esquema real del nodo y para validar.
