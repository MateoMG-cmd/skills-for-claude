# Troubleshooting checklist

| Symptom | Likely cause | Fix |
|---|---|---|
| Expression shows literally `{{ $json.x }}` | JSON string lacks leading `=` or field in fixed mode | `"={{ $json.x }}"` |
| `Cannot read properties of undefined` | Field missing, wrong path, empty previous output | optional chaining `?.`, check upstream output, Always Output Data |
| "Can't determine which item to use" / paired item errors | Item linking lost after Code/Aggregate/Merge | use `.first()/.all()`, or carry fields forward |
| Code node: "Code doesn't return items properly" | Missing `{json}` wrapper or wrong mode shape | return `[{json:{...}}]` (all) or `{json:{...}}` (each) |
| Branch silently stops, nothing after a node | Node returned 0 items | Always Output Data, or handle empty with IF on `$input.all().length` |
| Workflow runs N× expected / N API calls | Node runs once per input item | Aggregate/Limit first, or Execute Once; batching |
| Loop never ends or skips | Loop Over Items outputs mixed up | output 0 = done, 1 = loop; last loop node must connect back |
| Merge gives wrong/duplicate rows | Wrong mode/keys, duplicates on key | combine by field with unique keys; dedupe first |
| IF compares wrongly | Type mismatch (`"5"` vs 5), case sensitivity | convert types; loose type validation; lowercase |
| Webhook 404 | Using production URL while inactive (or test URL after one call) | activate workflow / click Listen for test event |
| Webhook returns before work done / empty | `responseMode` mismatch, no Respond node on a path | set `responseNode` and ensure every branch responds |
| 401/403 from API | Expired OAuth, wrong scopes, wrong header | re-auth credential; check scopes; test with curl equivalent |
| 429 | Rate limit | batching + Wait, retry with backoff |
| Timeout / memory crash on big data | Huge payload in one execution | paginate, sub-workflows, binary data on disk/S3, fewer saved executions |
| Duplicate records/messages | Retries or repeated triggers | idempotency key, upsert, Remove Duplicates |
| Schedule fires at wrong hour | Timezone not set | workflow settings timezone / Schedule rule timezone |
| Credential "not found" after import | IDs differ between instances | reselect credential in each node |
| Node shows "?" / unknown type | Wrong type string or community node not installed | correct `type`; install package |
| Code node can't `require` / read env | Sandboxed task runner, env access blocked by default in newer versions | use native nodes, credentials, or allow list on self-hosted |

## Debug method
1. Open the failed execution, find the first red node; read the *input* it received, not just the error.
2. Compare item counts between nodes (items-in vs items-out).
3. Pin data on the trigger and re-run from a middle node to isolate.
4. Simplify: disable branches, test the failing call alone (HTTP Request with the same body via curl/Postman).
5. After the fix, run with edge cases: empty array, one item, 100 items, missing optional fields, special characters.
