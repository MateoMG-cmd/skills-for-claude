# Anatomía del JSON de un workflow n8n

Contenido: estructura raíz · nodo · conexiones (main, múltiples salidas, IA) · settings · resource locators · reglas que evitan fallos de importación.

## Estructura raíz (el subconjunto seguro)

```json
{
  "name": "Nombre descriptivo",
  "nodes": [ ... ],
  "connections": { ... },
  "settings": { "executionOrder": "v1", "timezone": "America/Mexico_City" }
}
```

Entrega SOLO estas cuatro claves. Son las que aceptan tanto *Import from file / clipboard* de la UI como `POST /api/v1/workflows` de la API pública. La API rechaza claves de solo lectura (`id`, `active`, `tags`, `createdAt`, `versionId`, `pinData`, `meta`), así que incluirlas rompe el despliegue por API.

`settings` admite (API pública): `executionOrder`, `timezone`, `errorWorkflow` (ID), `saveDataErrorExecution`, `saveDataSuccessExecution` (`"all"`/`"none"`), `saveManualExecutions`, `saveExecutionProgress`, `executionTimeout` (segundos). Otras claves hacen que la API responda 400.

## Nodo

```json
{
  "parameters": { },
  "id": "uuid-v4-único",
  "name": "Nombre único en el workflow",
  "type": "n8n-nodes-base.httpRequest",
  "typeVersion": 4.2,
  "position": [480, 0],
  "credentials": { "httpHeaderAuth": { "id": "", "name": "Mi API" } },
  "webhookId": "uuid (solo Webhook y Chat Trigger)",
  "onError": "continueErrorOutput",
  "retryOnFail": true, "maxTries": 3, "waitBetweenTries": 2000,
  "alwaysOutputData": false, "executeOnce": false,
  "notes": "texto", "notesInFlow": true,
  "disabled": false
}
```

- **name**: único y sensible a mayúsculas. Las conexiones y expresiones (`$('Nombre')`) lo usan como clave; renombrar a mano sin actualizar referencias rompe el flujo.
- **id**: UUID v4 único. Duplicados corrompen el lienzo.
- **type**: `n8n-nodes-base.<nodo>` para nodos core/integraciones; `@n8n/n8n-nodes-langchain.<nodo>` para IA. Un tipo inventado importa pero aparece como nodo desconocido (signo "?"). Si no estás seguro del nombre exacto, di que hay que verificarlo en la instancia o usa HTTP Request.
- **typeVersion**: usa versiones conservadoras (ver `node-catalog.md`). n8n migra hacia arriba al abrir un nodo viejo, pero una versión más nueva que la de la instancia no abre.
- **position**: `[x, y]`, separación ~240 en x y ~180 en y; disparador a la izquierda, flujo de izquierda a derecha.
- **credentials**: la clave es el *tipo* de credencial (`slackApi`, `googleSheetsOAuth2Api`, `httpHeaderAuth`, `openAiApi`, `anthropicApi`, `postgres`…). Nunca incluyas secretos; `{"id": "", "name": "..."}` hace que n8n pida elegir la credencial tras importar. n8n no exporta ni importa valores secretos.
- **onError** (a nivel de nodo, no dentro de `parameters`): `stopWorkflow` (default), `continueRegularOutput` (sigue por la salida normal con el error como dato), `continueErrorOutput` (crea una salida extra de error, siempre la ÚLTIMA).

## Conexiones

Forma: `connections[nodoOrigen][tipo][índiceSalida] = [ {node, type, index} ]`.

```json
"connections": {
  "Webhook": { "main": [ [ { "node": "Validar", "type": "main", "index": 0 } ] ] },
  "Validar": { "main": [
      [ { "node": "Procesar", "type": "main", "index": 0 } ],      // salida 0 (true)
      [ { "node": "Responder 400", "type": "main", "index": 0 } ]  // salida 1 (false)
  ] }
}
```

Reglas:
- La clave es el **nombre** del origen. El destino va en `node` por nombre.
- Cada salida es una lista (puede ir a varios destinos en paralelo: fan-out).
- Salidas vacías se representan con `[]` (p. ej. IF solo con rama true: `[[...], []]`).
- Índices de salida por nodo: IF `0=true, 1=false` · Switch `0..n-1` reglas (+ fallback al final) · SplitInBatches `0=done, 1=loop` · Merge tiene dos **entradas** (`index` 0 y 1 en el destino) · `continueErrorOutput` añade una salida extra al final.
- **Un trigger nunca tiene entradas.**
- Para unir ramas (merge): ambas ramas conectan al Merge con `index: 0` y `index: 1`.

### Conexiones de IA (sub-nodos)

Los sub-nodos (modelo, memoria, tools, parsers) se conectan **hacia** el nodo padre con un tipo propio; la dirección es sub-nodo → agente:

```json
"Modelo Claude": { "ai_languageModel": [ [ { "node": "Agente", "type": "ai_languageModel", "index": 0 } ] ] },
"Memoria":       { "ai_memory":        [ [ { "node": "Agente", "type": "ai_memory",        "index": 0 } ] ] },
"Tool Pedidos":  { "ai_tool":          [ [ { "node": "Agente", "type": "ai_tool",          "index": 0 } ] ] },
"Parser":        { "ai_outputParser":  [ [ { "node": "Agente", "type": "ai_outputParser",  "index": 0 } ] ] }
```

Otros: `ai_embedding`, `ai_vectorStore`, `ai_document`, `ai_textSplitter`, `ai_retriever`, `ai_reranker`. Más detalle en `ai-agents.md`.

## Resource locators (`__rl`)

Muchos parámetros (documento de Sheets, canal de Slack, modelo, sub-workflow) usan:

```json
{ "__rl": true, "value": "ABC123", "mode": "id" }
```
`mode`: `list` (seleccionado de la lista; añade `cachedResultName`), `id`, `url`, `name`. Para generar sin acceso a la instancia usa `mode: "id"` con un valor placeholder claro (`REEMPLAZAR_ID_HOJA`).

## Sticky notes

```json
{ "parameters": { "content": "## Título\ntexto markdown", "height": 240, "width": 480, "color": 4 },
  "type": "n8n-nodes-base.stickyNote", "typeVersion": 1, "position": [-40, -320], "id": "...", "name": "Sticky Note" }
```
No se conectan. Úsalas para: propósito, credenciales requeridas, cómo probar, supuestos.

## Errores clásicos de importación

| Síntoma | Causa típica |
|---|---|
| Nodo con "?" / "node type not found" | `type` mal escrito o paquete (community node) no instalado |
| Nodos encimados en [0,0] | Sin `position` calculado |
| "Could not find property option" al abrir el nodo | Parámetro con valor inválido para esa `typeVersion` (p. ej. operación inexistente) |
| Expresión se muestra literal `{{ $json.x }}` | Falta el prefijo `=` en el string del parámetro |
| Credencial "missing" | Normal tras importar; el usuario la asigna |
| `POST /workflows` → 400 `additional properties` | Claves de solo lectura o `settings` no soportadas |
| Webhook responde vacío | `responseMode` no es `responseNode` aunque haya Respond to Webhook |
