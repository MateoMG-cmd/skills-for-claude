# Design patterns for production workflows

## Contents
1. Webhook API endpoint
2. Scheduled polling with dedupe
3. Batch processing and rate limits
4. Sub-workflows
5. Error workflow (central alerting)
6. Human-in-the-loop
7. Idempotency and state
8. Sync between two systems
9. Long-running / queue patterns
10. Sizing and naming conventions

## 1. Webhook API endpoint
Webhook (`responseMode: responseNode`) → validate (IF/Filter) → do work → **Respond to Webhook**. Invalid input → 400 response; auth failure → 401. Authenticate via the Webhook node's Header Auth / Basic Auth, or HMAC-verify in a Code node (Crypto) for providers like Stripe/GitHub/Shopify. For slow jobs: respond `202 Accepted` immediately, then continue processing (Respond to Webhook early, work after), and notify on completion.
Test URL vs Production URL differ (`/webhook-test/` vs `/webhook/`); the production one only works when the workflow is **active**.

## 2. Scheduled polling with dedupe
Schedule Trigger (set timezone, avoid every-minute unless needed) → fetch changes since last run (use a stored cursor: Workflow Static Data in Code, a Data Table, or a Sheet cell) → **Remove Duplicates** (mode "remove items processed in previous executions" on a stable ID) → process. Prefer provider **triggers/webhooks** over polling when available.

## 3. Batch processing and rate limits
Many items + rate-limited API: **Loop Over Items** (batch size N) → API node → **Wait** (or HTTP Request's *Batching* option: items per batch + interval) → loop back. Connect the Loop's *done* output to the next stage. For pagination use the HTTP Request *Pagination* option rather than hand-rolled loops. Aggregate results afterwards (Aggregate/Summarize) if a single summary is needed.

## 4. Sub-workflows
Extract repeated or complex logic into a workflow starting with **Execute Workflow Trigger** (define input schema) and call it with **Execute Workflow**. Benefits: reuse, smaller canvases, isolated testing, separate memory for heavy parts. Pass only the data needed; return a clean object.

## 5. Error workflow (central alerting)
Create one workflow: **Error Trigger** → Set (workflow name, failed node, message, execution URL, timestamp) → Slack/Email/Telegram → optionally log to a sheet/DB. In every production workflow: Settings → Error workflow → that one. Include `{{ $json.execution.url }}`, `{{ $json.workflow.name }}`, `{{ $json.execution.error.message }}`, `{{ $json.execution.lastNodeExecuted }}`.
Per-node: Retry On Fail for transient errors; *Continue (using error output)* to route a failed item to a dead-letter path (log + notify) while the rest proceed.

## 6. Human-in-the-loop
Send a message/email with approve/reject links, then **Wait** node (*On webhook call* or *On form submitted*; set a timeout/limit) → IF on the response. Many chat/app nodes also support "Send and Wait for Response". Always handle the timeout branch.

## 7. Idempotency and state
Anything that creates records or sends messages must survive a retry/duplicate trigger:
- Use **upsert / "create or update"** operations keyed by external ID.
- Check-then-create with a lookup node + IF.
- Remove Duplicates node; or store processed IDs in a Data Table/DB.
- Put a unique key (e.g. `Idempotency-Key` header) on payment/order APIs.
Avoid Workflow Static Data for critical state in test runs (only persists in production executions).

## 8. Sync between two systems
Trigger on source change → fetch full record → map fields (Edit Fields) → lookup in target by external ID → IF exists: Update else Create → write target ID back to the source (so reruns update instead of duplicating) → log. Normalise data (dates ISO 8601, phone E.164, lowercased emails) in one mapping node so the rule lives in one place.

## 9. Long-running / queue patterns
For high volume: n8n **queue mode** (workers + Redis) on self-hosted; keep each execution small (split big payloads with sub-workflows, process in pages). Avoid loading huge files in memory: use binary data on filesystem/S3 mode and stream where possible. Set execution timeouts and save-execution settings (don't save successful runs for very high-frequency workflows).

## 10. Sizing and naming conventions
- Workflow name: `[Area] Verb object – trigger` e.g. `[Sales] Sync new leads to CRM – webhook`.
- Node names: verb + object in sentence case; the same name is used in expressions, so keep it stable.
- ≤ ~25 nodes per canvas; beyond that, split into sub-workflows.
- One responsibility per workflow; tag by area/environment.
- Document with a sticky note: purpose, owner, credentials, external prerequisites, how to test.
- Environment separation: dev/prod via separate instances or credentials with the same name; never hardcode environment-specific IDs inside logic — keep them in one Set node at the top ("Config").
