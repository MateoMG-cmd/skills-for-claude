# Manejo de errores, reintentos y robustez

Contenido: las 4 capas · workflow global de errores · reintentos · idempotencia · rate limits · timeouts · checklist de producción.

Un flujo "profesional" no es el que funciona el día del demo, sino el que falla de forma visible, recuperable y sin duplicar efectos. Aplica estas capas de la más cercana al nodo a la más global.

## Capa 1 — Reintentos en el nodo (fallos transitorios)

En cada nodo que llama a algo externo (HTTP, APIs, BD, LLM):
```json
"retryOnFail": true, "maxTries": 3, "waitBetweenTries": 2000
```
Porque la mayoría de fallos de red / 429 / 5xx se resuelven solos. 3 intentos con 2–5 s es un buen default. Los errores permanentes (400, 401, 404) no se arreglan reintentando; para esos usa la capa 2. Para backoff real con 429 + `Retry-After`, usa un bucle con Wait.

## Capa 2 — Qué pasa si falla definitivamente (`onError`)

| Valor | Cuándo |
|---|---|
| `stopWorkflow` (default) | el paso es crítico y no tiene sentido seguir → que dispare el workflow de errores |
| `continueRegularOutput` | el fallo de ese item no debe frenar al resto y no necesitas tratarlo aparte |
| `continueErrorOutput` | **recomendado para procesos por lotes y APIs**: el item fallido sale por una segunda salida (la última) donde lo registras, notificas o reencolas, y el resto sigue |

Patrón: nodo externo (`continueErrorOutput`) → salida 0 camino feliz · salida 1 → nodo que arma `{item, error}` → guarda en tabla/hoja de "fallidos" y/o avisa. El mensaje del error llega en `$json.error` (revisa `$json.error.message`).

Para webhooks que responden a un cliente, cada rama de error debe terminar en un **Respond to Webhook** con código HTTP adecuado (400 entrada inválida, 502/503 dependencia caída), no dejar el request colgado.

## Capa 3 — Workflow global de errores

Un workflow aparte con **Error Trigger** → formatea → avisa (Slack/Telegram/email) con: nombre del flujo, nodo que falló, mensaje y URL de la ejecución.

```
Error Trigger → Set (armar texto) → Slack / Email
```
Datos del trigger: `$json.workflow.name`, `$json.workflow.id`, `$json.execution.id`, `$json.execution.url`, `$json.execution.error.message`, `$json.execution.lastNodeExecuted`.

Se enlaza en el flujo principal: *Settings → Error workflow*, o en el JSON `settings.errorWorkflow: "<ID del workflow de errores>"` (el ID solo existe tras importar el de errores; deja un placeholder y explica el paso).

Detalles que importan:
- El Error Trigger **solo se dispara con ejecuciones de producción** (workflow activo), no al probar manualmente; un flujo que "falla en silencio al probar" no es señal de que esté roto el handler.
- Un solo workflow de errores sirve para todos los flujos de la instancia.
- Un Error Trigger **dentro del mismo flujo** captura sus propios errores (útil para casos específicos), pero el patrón escalable es el global.
- Evita que el propio flujo de errores falle: pocos nodos, sin lógica frágil, con `onError: continueRegularOutput` en el nodo de aviso.

## Capa 4 — Observabilidad

- `settings.saveDataErrorExecution: "all"` siempre. En flujos de alto volumen, `saveDataSuccessExecution: "none"` para no inflar la BD.
- Nombres de nodos descriptivos (el log de ejecución se lee por nombre).
- Registra fallos de negocio (item rechazado, validación) en una tabla/hoja "Fallidos" con el payload y el motivo: permite reprocesar.
- `executionTimeout` (segundos) para que un flujo atascado no consuma recursos indefinidamente.

## Idempotencia (que reintentar no duplique)

Un flujo se puede ejecutar dos veces por reintentos, webhooks repetidos o reenvíos manuales. Diseña para que no importe:
- Guarda una **clave de idempotencia** (id del pedido/evento) y comprueba antes de crear (`Remove Duplicates`, Data Table, o consulta a la BD/API: "upsert" en lugar de "insert").
- Prefiere operaciones *upsert* / "append or update" con columna de coincidencia.
- Webhooks de terceros (Stripe, etc.): responde 200 rápido y procesa después; deduplica por `event.id`.
- Marca como procesado **después** de confirmar el efecto, no antes.

## Rate limits y volumen

- HTTP Request → `options.batching` (p. ej. 5 peticiones cada 1000 ms) o SplitInBatches + Wait.
- Lotes de 10–100 según la API; un lote por iteración reduce memoria.
- Cargas grandes (miles de items con binarios): sub-workflows para liberar memoria entre lotes; evita Code que mantenga todo en RAM.
- Paginación con tope (`maxRequests`).
- Para picos de webhooks: guarda el evento (cola/BD) y procesa con un flujo programado, o usa queue mode en self-hosted.

## Validación de entrada

Primer nodo tras el trigger: valida y normaliza (campos obligatorios, tipos, formato email, tamaños). Entrada inválida → respuesta 4xx clara o registro en "Fallidos"; nunca dejes que datos sucios lleguen a APIs de pago/escritura.

## Checklist de "listo para producción"

1. Trigger correcto (y webhook autenticado si es público).
2. Entrada validada y normalizada.
3. Cada llamada externa: timeout + retry + `onError` pensado.
4. Rama de fallo visible (alerta y/o tabla de fallidos).
5. Workflow global de errores enlazado.
6. Idempotencia o justificación de por qué no hace falta.
7. Rate limits / lotes / tope de paginación.
8. Sin secretos en parámetros ni en Code; solo credenciales de n8n.
9. Nombres claros + Sticky Note (propósito, credenciales, cómo probar, supuestos).
10. Probado con: caso feliz, entrada vacía/inválida, fallo de API simulado.
