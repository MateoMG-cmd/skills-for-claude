# AI agents and LLM workflows in n8n

## Choose the right building block
- **Basic LLM Chain** (`@n8n/n8n-nodes-langchain.chainLlm`): one-shot transformation/classification/extraction. Cheapest and most predictable — default choice.
- **Information Extractor / Text Classifier / Sentiment Analysis / Summarization Chain**: purpose-built, structured output.
- **AI Agent** (`@n8n/n8n-nodes-langchain.agent`, v2+): needs to decide which tools to call across several steps. Use only when the path isn't deterministic.
- **Deterministic workflow with an LLM step** beats a free-roaming agent for anything that must be reliable: let the workflow control the flow and the LLM do one bounded job.

## Agent anatomy (connections)
AI Agent ← `ai_languageModel` (OpenAI/Anthropic/Gemini chat model; required), ← `ai_memory` (Simple/Window Buffer Memory, Postgres/Redis chat memory; keyed by session ID), ← `ai_tool` (many), ← `ai_outputParser` (optional, structured output). Trigger usually Chat Trigger, Webhook, or an app trigger. Main input text via `promptType: "define"` + `text: "={{ $json.message }}"`; system prompt in `options.systemMessage`.

## Tools
Native tool nodes (Gmail, Sheets, Slack, HTTP Request Tool, Calculator, Code Tool, Wikipedia, SerpAPI…) and **Call n8n Workflow Tool** (wrap complex logic as a sub-workflow). In tool nodes use `={{ $fromAI('name', 'description', 'string') }}` for values the model should fill in. Give each tool a clear name and description — the model chooses by description.

## Prompting inside workflows
- System prompt: role, goal, constraints, output format, what to do when info is missing, today's date (`{{ $now }}`).
- Ask for **JSON output** and attach a Structured Output Parser (or JSON schema) when downstream nodes read fields; set temperature low (0–0.3) for extraction/classification.
- Keep untrusted text (emails, web pages, tickets) clearly delimited and tell the model to treat it as data, never instructions — prompt injection is real when the agent has tools that send or delete things.
- Least privilege: read-only tools by default; require human approval (Send and Wait) before destructive or outbound actions.

## RAG
Ingest: trigger → load docs → Text Splitter (recursive, ~500–1000 chars, 10–15% overlap) → Embeddings → Vector Store (insert; Qdrant, Pinecone, Supabase pgvector, in-memory only for tests). Query: Agent/Chain with Vector Store *as tool/retriever* with the same embedding model. Store metadata (source, URL, date) and cite it in answers. Re-ingestion must upsert by document ID to avoid duplicates.

## Cost, reliability, observability
- Cap loops/iterations (`maxIterations` on the agent), add timeouts, and retry transient API errors.
- Batch items; don't call an LLM per row if a rule or filter can pre-select.
- Log prompts/outputs (minus PII) to a table for review; track token usage where the model node exposes it.
- Add a fallback: if parsing fails or confidence is low → route to a human/queue instead of guessing.
- Test with 5–10 realistic inputs (including adversarial and empty ones) before activating.
