---
name: n8n-workflow-pro
description: Design, build, debug and review production-grade n8n workflows and automations, delivered as importable workflow JSON. Use whenever the user mentions n8n, workflows/flujos, automatizaciones, webhooks, triggers, "conectar X con Y", AI agents in n8n, Code node, expressions ({{ $json }}), error workflows, or asks to automate a process with n8n or similar low-code tools (Zapier/Make migrations too), even if they don't say "JSON". Also use to fix a broken n8n workflow, optimize or refactor one, or explain what a pasted workflow does.
---

# n8n Workflow Pro

Build n8n workflows the way a senior automation engineer would: understand the process first, choose the simplest node design that is reliable, make failures visible and recoverable, and deliver JSON that imports cleanly on the first try.

Reply in the user's language (the user often writes in Spanish). Keep node names, expressions and JSON in English-compatible form so they stay copy-pasteable.

## Why this skill exists
Model-written n8n JSON usually fails in the same ways: wrong `typeVersion`/parameter names, broken `connections`, expressions missing the leading `=`, Code nodes returning the wrong shape, no error handling, hardcoded secrets, and workflows that work for one item but break on many. The workflow below and the bundled validator exist to prevent those.

## Workflow

### 1. Understand the process (ask little, infer a lot)
Extract: **trigger** (what starts it, how often), **inputs** (shape of data), **systems** involved (and whether credentials exist), **outputs/side effects**, **volume**, and **what must never happen** (duplicates, lost data, spam). If the request is clear enough, build and state your assumptions at the top rather than interrogating. Ask (max 3 short questions) only when a wrong guess would produce a materially different workflow — e.g. unknown system, ambiguous trigger, destructive actions.

### 2. Design before JSON
Write a short plan: trigger → steps → outputs, plus where branches, loops, retries and error handling sit. Prefer built-in nodes over HTTP Request, and HTTP Request over Code, in that order, because native nodes handle auth, pagination, typing and future API changes. Use Code only for logic that is awkward otherwise. Read `references/design-patterns.md` for proven structures (webhook→respond, polling+dedupe, batch/loop, sub-workflows, queues, human-in-the-loop, error workflow).

### 3. Build the JSON
Read `references/workflow-json-format.md` for the exact schema, and `references/node-cheatsheet.md` for parameters of the common nodes. Read `references/expressions-and-code.md` before writing any expression or Code node. For LLM/agent workflows read `references/ai-agents.md`.

**Preferred way to generate JSON:** use the bundled builder instead of hand-writing it. `scripts/n8n_builder.py` (`from n8n_builder import Workflow`) creates unique ids, validated connections, `=`-prefixed expressions, IF/Filter/Switch condition blocks, AI sub-node links and an automatic left→right layout, so you only write the logic. See `examples/01_webhook_api.py`, `02_scheduled_etl.py`, `03_ai_agent.py` for complete patterns to copy. Hand-write JSON only for nodes the builder doesn't cover (use `wf.add("<full type>", version=...)`). More references: `references/node-catalog.md` (broader node/parameter catalog), `references/error-handling.md` (4 layers of error handling, retries, idempotency, production checklist), `references/deployment.md` and `scripts/deploy_workflow.py` (push to an n8n instance via the public API using `N8N_URL`/`N8N_API_KEY` env vars; offer only if the user asks and has network access to their instance, otherwise deliver the file).

Non-negotiables (each one prevents a real failure):
- **Unique, descriptive node names** ("Get open invoices", not "HTTP Request1") — connections are keyed by name, and names are what the user reads in the canvas and in error messages.
- **Every node connected**; exactly the right trigger. Lay out positions left→right in a 220–260 px grid so it opens tidy.
- **Credentials by reference only** (`"credentials": {"slackApi": {"id": "...", "name": "..."}}` or omit the id and tell the user which credential to select). Never put tokens, passwords or API keys in parameters.
- **Expressions start with `=`** in JSON (`"={{ $json.email }}"`); static strings must not.
- **Code nodes return `[{ json: {...} }]`** (all-items mode) or `{ json: {...} }` (each-item mode).
- **Set `typeVersion`** deliberately; use versions you are confident exist. When unsure of a node's current parameter names, say so and prefer a simpler/more stable alternative, or tell the user to open the node and confirm that field.
- **Idempotency**: anything that creates/sends/charges must be safe to re-run (dedupe key, upsert, "if not exists", or a record of processed IDs).
- **Error handling** on every workflow that touches the outside world (see below).
- **Sticky notes** summarising purpose, required credentials and setup, placed near the start.

### 4. Make it resilient
- Set a global **Error Workflow** (Error Trigger → notify with workflow name, node, message, execution URL). Offer to generate it as a second JSON.
- On flaky network nodes enable **Retry On Fail** (e.g. 3 tries, 1–5 s wait) and decide **On Error**: stop (default, for must-not-fail steps), continue (regular output), or continue (using error output) to route failures to a handler/dead-letter step.
- Validate inputs early (IF/Filter/Switch) and respond with clear 4xx on webhooks. Use **Stop and Error** to fail loudly on impossible states.
- Respect API limits: **Split In Batches / Loop Over Items** + **Wait**, and the node's built-in batching/pagination options.
- Webhooks: authenticate (header auth / HMAC), use **Respond to Webhook** when the caller needs a result, and don't do slow work before responding unless required.

### 5. Validate, then deliver
Always run the validator on the JSON you wrote:

```bash
python scripts/validate_workflow.py path/to/workflow.json
```

It checks JSON validity, unique names/ids, connection integrity, orphan nodes, missing trigger, expression prefix mistakes, suspicious Code node returns, hardcoded secrets and missing error handling. Fix every error; explain any warning you keep on purpose.

Deliver: (a) the `.json` file (via the file-delivery tool if available, otherwise a fenced code block), (b) a short summary: what it does, how to import (Workflows → ⋯ → Import from file, or paste into the canvas), credentials to create, placeholders to replace (URLs, IDs, sheet names), how to test (pinned data / "Execute workflow"), and the assumptions you made. Keep the summary to what the user needs to act.

## Debugging and reviewing existing workflows
When given a workflow or an error: read the JSON, trace the data item-by-item through the nodes, and name the specific cause (e.g. "`$json.id` is undefined after the Merge because both inputs use the same key", "IF node compares string to number", "Split In Batches `done` output not connected"). Check the common culprits in `references/troubleshooting.md` first. Provide the corrected JSON or the exact node changes, not generic advice.

## Version awareness
n8n moves fast (1.x → 2.x). Defaults changed in 2.x (e.g. task-runner isolation for Code nodes, more restricted env-var access and some risky nodes disabled by default on self-hosted). If the user states their version or hosting (Cloud vs self-hosted, Docker, queue mode), tailor to it; otherwise write version-conservative workflows and note anything that depends on newer nodes. When the user's question depends on something recent (new node, pricing, a changed API), check the official docs at docs.n8n.io before asserting it.

## Security and judgment
Treat webhook inputs as untrusted (validate, never pass straight to Execute Command or SQL — use parameterised queries). Don't build workflows that bulk-message people without consent, scrape against terms of service, or exfiltrate data; say so and offer a compliant alternative. Keep PII out of logs and notifications where possible.
